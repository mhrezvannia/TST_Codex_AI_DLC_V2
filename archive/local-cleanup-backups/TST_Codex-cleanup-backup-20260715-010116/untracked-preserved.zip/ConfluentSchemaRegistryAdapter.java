package com.linercore.platform.booking.messaging;

import com.linercore.platform.booking.applicationservice.port.EventPublicationException;
import com.linercore.platform.booking.applicationservice.port.SchemaRegistryPort;
import com.linercore.platform.booking.applicationservice.port.SchemaSubject;
import com.linercore.platform.messaging.AvroSchemaRepository;
import com.linercore.platform.messaging.SchemaRegistrar;

public class ConfluentSchemaRegistryAdapter implements SchemaRegistryPort {
    private static final String COMPATIBILITY = "BACKWARD";
    private final SchemaRegistrar registrar;
    private final AvroSchemaRepository schemas;

    public ConfluentSchemaRegistryAdapter(SchemaRegistrar registrar, AvroSchemaRepository schemas) {
        this.registrar = registrar;
        this.schemas = schemas;
    }

    @Override
    public SchemaSubject ensureRegistered(String eventType, String schemaVersion) {
        try {
            String subject = registrar.ensureRegistered(eventType, schemas.schemaFor(eventType), COMPATIBILITY);
            return new SchemaSubject(subject, eventType, schemaVersion, COMPATIBILITY);
        } catch (com.linercore.platform.messaging.EventPublicationException ex) {
            throw new EventPublicationException(ex.code(), ex.getMessage(), ex.retryable());
        }
    }
}
