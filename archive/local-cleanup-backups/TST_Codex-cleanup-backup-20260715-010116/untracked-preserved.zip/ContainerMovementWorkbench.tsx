"use client";

import { useEffect, useMemo, useState, type CSSProperties, type FormEvent } from "react";
import { WorkflowCommandCenter } from "@erp/ui";
import type { JourneyView, MovementEventType } from "../lib/container-movement";

type Props = {
  initialJourneys: JourneyView[];
};

type IntakeDraft = {
  bookingId: string;
  customerId: string;
  originLocationId: string;
  destinationLocationId: string;
  containerId: string;
  equipmentTypeId: string;
};

type MovementDraft = {
  eventType: MovementEventType;
  locationId: string;
};

export function ContainerMovementWorkbench({ initialJourneys }: Props) {
  const [journeys, setJourneys] = useState(initialJourneys);
  const [selectedId, setSelectedId] = useState(initialJourneys[0]?.id ?? "");
  const [status, setStatus] = useState("Fallback journey data loaded");
  const [busy, setBusy] = useState(false);
  const [intake, setIntake] = useState<IntakeDraft>({
    bookingId: "demo-booking",
    customerId: "cust-demo",
    originLocationId: "loc-origin",
    destinationLocationId: "loc-destination",
    containerId: "CONT-DEMO-001",
    equipmentTypeId: "40HC"
  });
  const [movement, setMovement] = useState<MovementDraft>({ eventType: "ACTUAL_DEPARTURE", locationId: "loc-origin" });
  const selected = useMemo(() => journeys.find((journey) => journey.id === selectedId) ?? journeys[0], [journeys, selectedId]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const response = await fetch("/api/journeys?limit=25");
        if (!response.ok) {
          if (!cancelled) setStatus(`Movement service unavailable (${response.status}); showing fallback data`);
          return;
        }
        const page = await response.json() as { items?: JourneyView[] };
        if (!cancelled && page.items?.length) {
          setJourneys(page.items);
          setSelectedId(page.items[0].id);
          setStatus("Live journeys loaded");
        }
      } catch {
        if (!cancelled) setStatus("Movement service unavailable; showing fallback data");
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  async function intakeBooking(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    const now = new Date().toISOString();
    const response = await fetch("/api/booking-confirmed", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        eventId: `booking-confirmed-${Date.now()}`,
        eventType: "booking.confirmed",
        schemaVersion: "1.0.0",
        source: "apps-container-movement",
        occurredAt: now,
        correlationId: `movement-ui-${Date.now()}`,
        idempotencyKey: `booking-confirmed-${intake.bookingId}-${Date.now()}`,
        bookingId: intake.bookingId,
        bookingRevision: 1,
        pricingRef: "ui-pricing",
        customerId: intake.customerId,
        originLocationId: intake.originLocationId,
        destinationLocationId: intake.destinationLocationId,
        containerId: intake.containerId,
        equipmentTypeId: intake.equipmentTypeId
      })
    });
    await handleMutation(response, "Booking-confirmed intake complete");
  }

  async function captureMovement(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selected) return;
    setBusy(true);
    const response = await fetch(`/api/journeys/${selected.id}/movements`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        eventType: movement.eventType,
        containerId: selected.containerId,
        locationId: movement.locationId,
        eventTime: new Date().toISOString(),
        actorSubjectId: "local-user",
        idempotencyKey: `movement-${selected.id}-${movement.eventType}-${Date.now()}`,
        correlationId: `movement-ui-${Date.now()}`
      })
    });
    await handleMutation(response, "Movement captured");
  }

  async function handleMutation(response: Response, successMessage: string) {
    const payload = await response.json().catch(() => ({}));
    setBusy(false);
    if (!response.ok) {
      setStatus(`${successMessage} failed (${response.status}): ${payload.error ?? payload.message ?? "service error"}`);
      return;
    }
    const journey = payload as JourneyView;
    setJourneys((current) => [journey, ...current.filter((item) => item.id !== journey.id)]);
    setSelectedId(journey.id);
    setStatus(successMessage);
  }

  return (
    <main style={styles.page}>
      <header style={styles.header}>
        <div>
          <p style={styles.eyebrow}>Equipment Flow</p>
          <h1 style={styles.title}>Container Movement</h1>
        </div>
        <div aria-live="polite" style={styles.status}>{status}</div>
      </header>

      <WorkflowCommandCenter
        queue={[
          { label: "Journey intake", owner: "Movement", status: selected?.status ?? "Ready" },
          { label: "Movement capture", owner: "Operations", status: selected?.history.length ? "Events captured" : "Waiting", severity: selected?.history.length ? "normal" : "attention" },
          { label: "Booking callback", owner: "Booking", status: "Outbox event queued" }
        ]}
        evidence={[
          { label: "Journeys", value: `${journeys.length} loaded` },
          { label: "Selected", value: selected?.containerId ?? "None" },
          { label: "History", value: `${selected?.history.length ?? 0} events` }
        ]}
        exceptions={selected?.status === "EXCEPTION" ? [{ label: "Movement exception", owner: "Operations", status: "Review", severity: "blocked" }] : []}
      />

      <section style={styles.grid}>
        <form onSubmit={intakeBooking} style={styles.panel}>
          <h2 style={styles.sectionTitle}>Booking-confirmed intake</h2>
          <label style={styles.label}>Booking<input style={styles.input} value={intake.bookingId} onChange={(event) => setIntake({ ...intake, bookingId: event.target.value })} /></label>
          <label style={styles.label}>Customer<input style={styles.input} value={intake.customerId} onChange={(event) => setIntake({ ...intake, customerId: event.target.value })} /></label>
          <label style={styles.label}>Origin<input style={styles.input} value={intake.originLocationId} onChange={(event) => setIntake({ ...intake, originLocationId: event.target.value })} /></label>
          <label style={styles.label}>Destination<input style={styles.input} value={intake.destinationLocationId} onChange={(event) => setIntake({ ...intake, destinationLocationId: event.target.value })} /></label>
          <label style={styles.label}>Container<input style={styles.input} value={intake.containerId} onChange={(event) => setIntake({ ...intake, containerId: event.target.value })} /></label>
          <label style={styles.label}>Equipment<input style={styles.input} value={intake.equipmentTypeId} onChange={(event) => setIntake({ ...intake, equipmentTypeId: event.target.value })} /></label>
          <button type="submit" disabled={busy} style={styles.buttonPrimary}>Create journey</button>
        </form>

        <section style={styles.panel}>
          <div style={styles.toolbar}>
            <h2 style={styles.sectionTitle}>Journeys</h2>
            <span>{journeys.length}</span>
          </div>
          <div style={styles.list}>
            {journeys.map((journey) => (
              <button key={journey.id} type="button" style={journey.id === selected?.id ? styles.rowActive : styles.row} onClick={() => setSelectedId(journey.id)}>
                <strong>{journey.containerId}</strong>
                <span>{journey.bookingId}</span>
                <code>{journey.status}</code>
              </button>
            ))}
          </div>
        </section>

        <section style={styles.detail}>
          <h2 style={styles.sectionTitle}>Journey detail</h2>
          {selected ? (
            <>
              <dl style={styles.dl}>
                <div><dt>ID</dt><dd>{selected.id}</dd></div>
                <div><dt>Booking</dt><dd>{selected.bookingId} r{selected.bookingRevision}</dd></div>
                <div><dt>Route</dt><dd>{selected.expectedMovements.map((item) => item.locationId).join(" -> ")}</dd></div>
                <div><dt>Status</dt><dd>{selected.status}</dd></div>
              </dl>
              <form onSubmit={captureMovement} style={styles.captureForm}>
                <label style={styles.labelDark}>Event
                  <select style={styles.input} value={movement.eventType} onChange={(event) => setMovement({ ...movement, eventType: event.target.value as MovementEventType })}>
                    <option value="ACTUAL_DEPARTURE">Actual departure</option>
                    <option value="ACTUAL_ARRIVAL">Actual arrival</option>
                    <option value="DELIVERED">Delivered</option>
                    <option value="EXCEPTION">Exception</option>
                  </select>
                </label>
                <label style={styles.labelDark}>Location<input style={styles.input} value={movement.locationId} onChange={(event) => setMovement({ ...movement, locationId: event.target.value })} /></label>
                <button type="submit" disabled={busy} style={styles.buttonPrimary}>Capture movement</button>
              </form>
              <ol style={styles.history}>
                {selected.history.map((event) => (
                  <li key={event.eventId}><strong>{event.eventType}</strong> at {event.locationId}</li>
                ))}
              </ol>
            </>
          ) : <p>No journey selected.</p>}
        </section>
      </section>
    </main>
  );
}

const styles: Record<string, CSSProperties> = {
  page: { display: "flex", flexDirection: "column", gap: 16, padding: 26, background: "#f4f7fb", color: "#102235" },
  header: { display: "flex", justifyContent: "space-between", gap: 18, alignItems: "center" },
  eyebrow: { margin: "0 0 7px", fontSize: 12, color: "#2f73c4", fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" },
  title: { margin: 0, fontSize: 32, lineHeight: 1.1, fontWeight: 700 },
  status: { border: "1px solid #d7e2ef", borderRadius: 8, padding: "9px 12px", background: "#ffffff", color: "#607080", fontSize: 13 },
  grid: { display: "grid", gridTemplateColumns: "300px minmax(0, 1fr) 380px", gap: 16, alignItems: "start" },
  panel: { background: "#ffffff", border: "1px solid #e1e7ee", borderRadius: 8, padding: 18, boxShadow: "0 10px 30px rgba(16, 34, 53, 0.05)" },
  detail: { background: "#0c2742", color: "#ffffff", border: "1px solid #0c2742", borderRadius: 8, padding: 18, boxShadow: "0 14px 34px rgba(12, 39, 66, 0.18)" },
  sectionTitle: { margin: 0, fontSize: 18, fontWeight: 700 },
  label: { display: "flex", flexDirection: "column", gap: 4, marginTop: 10, fontSize: 13, color: "#40556a" },
  labelDark: { display: "flex", flexDirection: "column", gap: 4, marginTop: 10, fontSize: 13, color: "#d4e0ec" },
  input: { minWidth: 0, border: "1px solid #cdd7e2", borderRadius: 6, padding: "8px 9px", background: "#ffffff", color: "#102235" },
  buttonPrimary: { border: "1px solid #11427a", borderRadius: 6, background: "#11427a", color: "#ffffff", padding: "8px 11px", fontWeight: 700, marginTop: 12 },
  toolbar: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  list: { display: "grid", gap: 8 },
  row: { display: "grid", gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1fr) auto", gap: 10, alignItems: "center", border: "1px solid #e1e7ee", borderRadius: 8, background: "#ffffff", padding: 10, textAlign: "left" },
  rowActive: { display: "grid", gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1fr) auto", gap: 10, alignItems: "center", border: "1px solid #11427a", borderRadius: 8, background: "#edf3fb", padding: 10, textAlign: "left" },
  dl: { display: "grid", gap: 10, color: "#d4e0ec" },
  captureForm: { borderTop: "1px solid #1f476d", marginTop: 14, paddingTop: 12 },
  history: { marginTop: 14, color: "#d4e0ec" }
};
