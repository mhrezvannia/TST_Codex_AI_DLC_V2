package com.linercore.platform.identity.dataaccess.jdbc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.linercore.platform.identity.applicationservice.port.AuthorizationAuditRepository;
import com.linercore.platform.identity.domain.model.AuthorizationAuditRecord;
import java.sql.Timestamp;
import org.springframework.jdbc.core.JdbcTemplate;

public class JdbcAuthorizationAuditRepository implements AuthorizationAuditRepository {
    private final JdbcTemplate jdbc;
    private final JdbcJson json;

    public JdbcAuthorizationAuditRepository(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc;
        this.json = new JdbcJson(mapper);
    }

    public void append(AuthorizationAuditRecord record) {
        jdbc.update("""
                INSERT INTO identity_authorization_audit
                    (audit_id, event_type, actor_subject_id, target_subject_id, resource, action, result,
                     occurred_at, correlation_id, snapshot)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                record.auditId(),
                record.eventType(),
                record.actorSubjectId(),
                record.targetSubjectId(),
                record.resource(),
                record.action(),
                record.result(),
                record.occurredAt() == null ? null : Timestamp.from(record.occurredAt()),
                record.correlationId(),
                json.write(record));
    }
}
