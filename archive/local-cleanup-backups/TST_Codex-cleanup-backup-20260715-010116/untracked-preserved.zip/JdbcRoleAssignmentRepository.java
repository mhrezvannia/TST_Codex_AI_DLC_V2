package com.linercore.platform.identity.dataaccess.jdbc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.linercore.platform.identity.applicationservice.port.RoleAssignmentRepository;
import com.linercore.platform.identity.domain.model.RoleAssignment;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import org.springframework.jdbc.core.JdbcTemplate;

public class JdbcRoleAssignmentRepository implements RoleAssignmentRepository {
    private final JdbcTemplate jdbc;
    private final JdbcJson json;

    public JdbcRoleAssignmentRepository(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc;
        this.json = new JdbcJson(mapper);
    }

    public List<RoleAssignment> findActiveBySubjectId(String subjectId) {
        return jdbc.query("""
                SELECT snapshot FROM identity_role_assignments
                WHERE subject_id = ? AND status = 'ACTIVE'
                ORDER BY assigned_at
                """, (rs, rowNum) -> read(rs), subjectId);
    }

    public Optional<RoleAssignment> findBySubjectAndRole(String subjectId, String roleId) {
        List<RoleAssignment> rows = jdbc.query("""
                SELECT snapshot FROM identity_role_assignments
                WHERE subject_id = ? AND role_id = ?
                ORDER BY version DESC
                LIMIT 1
                """, (rs, rowNum) -> read(rs), subjectId, roleId);
        return rows.stream().findFirst();
    }

    public RoleAssignment save(RoleAssignment assignment) {
        jdbc.update("""
                INSERT INTO identity_role_assignments
                    (assignment_id, subject_id, role_id, status, assigned_at, version, snapshot)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (assignment_id) DO UPDATE SET
                    subject_id = EXCLUDED.subject_id,
                    role_id = EXCLUDED.role_id,
                    status = EXCLUDED.status,
                    assigned_at = EXCLUDED.assigned_at,
                    version = EXCLUDED.version,
                    snapshot = EXCLUDED.snapshot
                """,
                assignment.assignmentId(),
                assignment.subjectId(),
                assignment.roleId(),
                assignment.status().name(),
                assignment.assignedAt() == null ? null : Timestamp.from(assignment.assignedAt()),
                assignment.version(),
                json.write(assignment));
        return assignment;
    }

    private RoleAssignment read(ResultSet rs) throws SQLException {
        return json.read(rs.getString("snapshot"), RoleAssignment.class);
    }
}
