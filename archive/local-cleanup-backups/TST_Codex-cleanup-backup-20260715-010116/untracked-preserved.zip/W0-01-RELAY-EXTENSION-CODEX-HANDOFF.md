# W0-01 Relay Extension — Codex Handoff (booking / CMM / charge)

> **Goal:** give booking-service, container-movement-service, and charge-agreement-service the same *real* outbox → Kafka eventing that reference-data-service already has, by adopting the shared `platform-messaging` module. Reference-data is the finished, verified template — replicate its pattern, do not reinvent it.
>
> **Split:** the shared module + reference-data refactor were done and verified separately (that's your foundation). Your job is the repetitive per-service adoption. Every service exits through the two audits.

## Read first (the template + the shared module)

1. `docs/intents/W0-01-platform-eventing-foundation.md` + `docs/codex-review-findings.md` (C1–C5, H1 — what "real" means).
2. **Shared module** `services/platform-messaging/` — reuse these; never copy them:
   - `AvroSchemaRepository` (load .avsc by event type), `KafkaGenericRecordPublisher` (send a GenericRecord → `BrokerMetadata`), `SchemaRegistrar` + `ConfluentSchemaRegistrar`, `AvroProducerConfig` (producer props), `LocalNoopMarker` + `NoopMessagingGuard`, `ScheduledOutboxRelay` + `OutboxRelay` + `RelayBatchResult`, `BrokerMetadata`, `EventPublicationException`.
   - Test pattern: `services/platform-messaging/src/test/java/.../PlatformMessagingTest.java`.
3. **Reference-data template** (copy this shape per service):
   - Enriched outbox: `reference-data-service/.../domain/outbox/OutboxEvent.java` (lifecycle: status, attemptCount, nextAttemptAt, claimedBy, claimedAt, lastError; `published(metadata,now)` / `retryable(...)` / `failedPermanent(...)`).
   - Port: `.../applicationservice/port/OutboxRepository.java` (`enqueue`, `claimAvailable`, `save`, `findByEventId`, `findStatuses`).
   - JDBC: `.../dataaccess/jdbc/JdbcOutboxRepository.java` + the outbox table schema (status/attempt/claim columns + a claim index).
   - App-service: `ReferenceDataApplicationService.publishOutboxBatch(workerId, batchSize)` → claim → `schemaRegistry.ensureRegistered` → `publisher.publish` → `outbox.save(published/retryable/failedPermanent)`; `@Transactional`.
   - Messaging adapters over the shared module: `messaging/.../KafkaReferenceEventPublisher.java` (event→GenericRecord mapping + shared publisher), `ConfluentSchemaRegistryAdapter.java` (over shared `SchemaRegistrar`), `LocalNoop*.java` (implement shared `LocalNoopMarker`).
   - Wiring: `container/.../ReferenceDataMessagingConfiguration.java` (kafka / local-noop profiles + shared `ScheduledOutboxRelay` bean), `ReferenceDataNoopMessagingGuard.java` (ApplicationRunner using shared `NoopMessagingGuard`), `@EnableScheduling` on the application class.
   - Serde test: `messaging/src/test/java/.../KafkaReferenceEventPublisherSerdeTest.java`.

## Per-service work (do booking first, then CMM, then charge)

For **each** service, replicate the template:

1. **Enrich the outbox event** with lifecycle fields + transitions (`published`/`retryable`/`failedPermanent`), modelled on reference-data's `OutboxEvent`. (Booking/CMM/charge currently have enqueue-only events with no lifecycle.)
2. **Expand the `OutboxRepository` port** to `enqueue` + `claimAvailable` + `save` (+ status views), modelled on reference-data.
3. **JDBC repository + schema migration:** implement the new methods; add outbox-table columns (`status`, `attempt_count`, `next_attempt_at`, `claimed_by`, `claimed_at`, `last_error_code`, `last_error_message`) + a claim index. Update the service's `db/*-schema.sql` and seeds if needed.
4. **App-service `publishOutboxBatch`** (claim → register → publish → mark), returning a `PublishBatchResult`; wrap the state-change + enqueue paths in `@Transactional`.
5. **Messaging adapters over the shared module:** a `Kafka<Service>EventPublisher` that maps the service's event to a `GenericRecord` and delegates to the shared `KafkaGenericRecordPublisher` (translate the shared `EventPublicationException`/`BrokerMetadata` back to the service's port types, exactly as reference-data does); a `ConfluentSchemaRegistryAdapter` over the shared `SchemaRegistrar`; `LocalNoop*` implementing shared `LocalNoopMarker`.
6. **Messaging config** (`<service>MessagingConfiguration`): kafka-profile beans wiring `AvroProducerConfig.avroProducerProps` → `KafkaTemplate<String,GenericRecord>` → `KafkaGenericRecordPublisher`, the adapters, and a `ScheduledOutboxRelay` bean (behind `@ConditionalOnProperty`) whose `OutboxRelay` lambda calls the app-service `publishOutboxBatch` and maps to `RelayBatchResult`; local-noop-profile beans; a `NoopMessagingGuard` `ApplicationRunner`; `@EnableScheduling` on the app.
7. **Avro schema resource:** put the service's event schema (`booking.confirmed.avsc`, `containermovement.status.avsc`, agreement event) under `<service>/messaging/src/main/resources/avro/<eventType>.avsc`, matching `contracts/avro/` and the field names in `docs/enterprise-contracts/`.
8. **Runtime config:** `application-local.yaml` (kafka bootstrap, schema-registry url, outbox-relay) + `compose.yaml` env (`SPRING_PROFILES_ACTIVE: local,kafka`, `KAFKA_BOOTSTRAP_SERVERS`, `SCHEMA_REGISTRY_URL`, topic).
9. **Serde test** per service (model on `KafkaReferenceEventPublisherSerdeTest`): run the service's real event→record mapping through the Confluent Avro serializer + `MockSchemaRegistryClient` and assert every field round-trips.
10. **Maven:** add `platform-messaging` as a dependency of each `<service>-messaging` module.

## Hard rules

- **No placeholder satisfies a DoD.** Placeholders live only behind a `local-noop` profile guarded by `NoopMessagingGuard`; a no-op must never mark an outbox row PUBLISHED.
- **Use the shared module** — do not copy the publisher/registrar/relay into each service.
- **Field names come from the contract `.avsc`.** Zero divergence (this is the fix for the `equipmentTypeCode`/`equipmentTypeId` class of bug).
- **Do NOT change the Booking→CMM synchronous HTTP call** (`BookingApiController.publishBookingConfirmed`). Replacing it with the real event belongs to intent **W1-01**, not here. This intent makes the *outbox* real; W1-01 rewires Booking→CMM onto it.
- **`@Transactional`** around every state-change + outbox-enqueue path.

## Build / environment notes (this machine)

- Maven Central is throttled here; a mirror is configured in `~/.m2/settings.xml` (Aliyun or Google GCS mirror of central). If a large jar fails with a TLS `bad_record_mac`, just re-run — it's transient. Keep the build online (not `-o`) so cached-from-mixed-mirror artifacts revalidate.
- **Embedded-broker tests do not run in restricted/loopback-blocked environments** (KRaft and ZooKeeper both fail to bind localhost). Verify with the serde round-trip test (in-JVM, no broker) + the Docker Compose live-proof.

## Exit gate (per service, and for the intent)

1. `mvn -f services/pom.xml test` green, including the new serde test.
2. `.claude/skills/aidlc-audit/detectors.sh` — no production placeholder publishers, no dead-end outboxes, `@Scheduled` present, `@Transactional` present.
3. `.claude/skills/erp-fidelity-audit/detectors.sh` — field names match the contracts.
4. **Live Compose proof** (when Docker is available): drive a state change in each service and observe its event on the real Kafka topic (SR-validated); capture evidence to `artifacts/`.

Report the evidence paths. Claude reviews the result against the two audits before the intent is called done.
