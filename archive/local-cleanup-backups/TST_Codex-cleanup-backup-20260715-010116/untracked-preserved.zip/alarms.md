# Alarms - LinerCore Enterprise

## Source Context

These alarms consume `performance-design`, `security-design`, `reliability-design`, `monitoring-design`, and `infrastructure-services`. They are logical alert definitions until a production monitoring backend is provisioned.

## Alert Rules

| Alarm | Severity | Signal | Threshold | Owner |
|---|---|---|---|---|
| Readiness failed | Page | Local/CI readiness evidence | Any `failed` required evidence item | Operations |
| Live readiness blocked | Ticket | Local readiness evidence | Any live blocker remains for staging/prod promotion | Local Runtime Platform |
| Contract health red | Page | Contract health snapshot | Any blocking contract/catalog failure | Contract Platform |
| Outbox lag high | Ticket/Page by environment | Outbox lag | Above SLO threshold for 5 minutes | Owning service |
| Event freshness stale | Ticket | Event freshness | Freshness exceeds configured threshold | Owning service |
| Authorization denial spike | Ticket | Authorization decisions | Spike over baseline or suspicious repeated denials | Identity/Security |
| Error rate high | Page | HTTP/service error rate | Above SLO threshold for 5 minutes | Owning service |
| Trace/log correlation missing | Ticket | Correlation evidence | Missing `X-Correlation-Id` across HTTP/event/log/trace | Operations |

## Routing

- Page-worthy alerts route to on-call once on-call ownership exists.
- Ticket alerts create backlog/incident items with owner, severity, mitigation, and evidence path.
- No alert should page on local-only development noise unless it blocks release evidence.

## Gaps

SNS/PagerDuty/Slack routing is not configured. CloudWatch/Grafana alert provisioning must be added after production monitoring target selection.
