# Anomaly Config - LinerCore Enterprise

## Source Context

This anomaly configuration consumes `performance-design`, `security-design`, `reliability-design`, `monitoring-design`, and `infrastructure-services`. It defines candidate anomaly detectors for later production monitoring.

## Candidate Detectors

| Detector | Signal | Action |
|---|---|---|
| Error-rate anomaly | Service 5xx/error rate by service | Page if sustained and user-impacting. |
| Latency anomaly | p95/p99 request latency by service | Ticket or page based on SLO breach severity. |
| Authorization anomaly | Denied decisions by subject/service/action | Ticket security owner for investigation. |
| Outbox lag anomaly | Oldest unpublished event age | Ticket owning service; page if release/flow blocked. |
| Event freshness anomaly | Event freshness seconds by topic/schema | Ticket event owner. |
| Readiness blocker anomaly | Repeated blocked evidence by owner/source | Create operational backlog item. |

## Baseline Requirements

- At least one stable staging/prod environment.
- Consistent metric labels without high-cardinality correlation ids.
- Retention long enough to compare daily/weekly patterns.
- Owner mapping for every service and event seam.

## Current Status

Anomaly detection is designed but not provisioned. Local observability smoke proves configuration files exist; live baselines require production/staging telemetry.
