export type BookingStatus = "DRAFT" | "VALIDATED" | "PRICING_PENDING" | "PRICED" | "CONFIRMED" | "AMENDED" | "RECONFIRMED" | "EXCEPTION";

export type BookingView = {
  id: string;
  bookingNumber: string;
  revision: number;
  status: BookingStatus;
  customerId: string;
  originLocationId: string;
  destinationLocationId: string;
  equipmentType: string;
  pricingSnapshot?: {
    pricingRequestId: string;
    pricingQuoteId: string;
    status: string;
    quotedAmounts: Record<string, string>;
    receivedAt: string;
    correlationId: string;
  } | null;
  attributes: Record<string, string>;
};

export type BookingList = {
  items: BookingView[];
  returned: number;
};

export const fallbackBookings: BookingView[] = [
  {
    id: "demo-booking",
    bookingNumber: "BKG-DEMO-001",
    revision: 1,
    status: "DRAFT",
    customerId: "cust-demo",
    originLocationId: "loc-origin",
    destinationLocationId: "loc-destination",
    equipmentType: "40HC",
    pricingSnapshot: null,
    attributes: { containerId: "CONT-DEMO-001" }
  }
];

export function bookingServiceUrl() {
  return (process.env.BOOKING_SERVICE_URL ?? "http://localhost:8085").replace(/\/+$/, "");
}

export async function proxyJson(path: string, init: RequestInit, correlationId: string) {
  try {
    const response = await fetch(`${bookingServiceUrl()}${path}`, {
      ...init,
      headers: {
        "content-type": "application/json",
        "x-correlation-id": correlationId,
        ...(init.headers ?? {})
      },
      signal: AbortSignal.timeout(5000)
    });
    const data = await safeJson(response);
    return Response.json(data, { status: response.status });
  } catch (error) {
    return Response.json({
      error: "booking service unavailable",
      detail: error instanceof Error ? error.message : String(error),
      correlationId
    }, { status: 503 });
  }
}

export function correlationId(request: Request, prefix = "booking-ui") {
  return request.headers.get("x-correlation-id") ?? `${prefix}-${crypto.randomUUID()}`;
}

async function safeJson(response: Response) {
  const text = await response.text();
  if (!text) {
    return null;
  }
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}
