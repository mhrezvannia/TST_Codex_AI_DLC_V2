# Build Instructions - LinerCore Enterprise

## Source Context

These instructions consume every construction unit `code-generation-plan` and `code-summary`, including contract catalog, local runtime, identity/security, reference events, Booking, Charge, CMM, integration seams, Enterprise Web, and observability/readiness outputs.

## Environment Setup

- Use Windows PowerShell from `D:\TST_Codex`.
- Refresh frontend dependencies when package manifests change: `corepack yarn install --mode=skip-build`.
- Use the repository JDK for backend commands:

```powershell
$env:JAVA_HOME=(Resolve-Path .local-tools\jdk-21).Path
$env:Path="$env:JAVA_HOME\bin;$env:Path"
```

- Docker is required only for full live runtime readiness. Offline build, contract, and unit checks do not require Docker.

## Build Commands

| Area | Command |
|---|---|
| Backend reactor | `.\.local-tools\apache-maven\bin\mvn.cmd -f services\pom.xml test` |
| Reference Data typecheck | `corepack yarn workspace @erp/app-reference-data typecheck` |
| Charge Agreements typecheck | `corepack yarn workspace @erp/app-charge-agreements typecheck` |
| Auth typecheck | `corepack yarn workspace @erp/app-auth typecheck` |
| Shared UI typecheck | `corepack yarn workspace @erp/ui typecheck` |
| Contract catalog | `node scripts\validate-contract-catalog.mjs` |
| Offline contract verification | `node scripts\verify-contract-providers.mjs` |

## Troubleshooting

- If Maven reports `JAVA_HOME environment variable is not defined correctly`, set `JAVA_HOME` to `.local-tools\jdk-21`.
- If `@erp/ui` cannot find `tsc`, run `corepack yarn install --mode=skip-build`; the UI package has a direct TypeScript dev dependency.
- If local readiness is `blocked`, inspect `artifacts\readiness\local-readiness.json`; Docker/live services may be unavailable while offline checks still pass.
