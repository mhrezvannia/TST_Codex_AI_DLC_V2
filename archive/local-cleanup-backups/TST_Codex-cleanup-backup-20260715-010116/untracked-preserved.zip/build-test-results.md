# Build Test Results - LinerCore Enterprise

## Source Context

These results validate the construction `code-generation-plan` and `code-summary` outputs for all completed units.

## Executed Commands

| Command | Status | Result |
|---|---|---|
| `.\.local-tools\apache-maven\bin\mvn.cmd -f services\pom.xml test` with `JAVA_HOME=.local-tools\jdk-21` | Passed | 31-module reactor success; 90 tests, 0 failures, 0 errors, 0 skipped. |
| `node --test scripts\*.test.mjs` | Passed | 48 tests passed. |
| `node scripts\validate-contract-catalog.mjs` | Passed | Catalog `status: ok`, 13 contracts, green health snapshot. |
| `node scripts\verify-contract-providers.mjs` | Passed | Offline verification `status: ok`; live verification skipped without `--live`. |
| `corepack yarn workspace @erp/app-reference-data typecheck` | Passed | No TypeScript errors. |
| `corepack yarn workspace @erp/app-charge-agreements typecheck` | Passed | No TypeScript errors. |
| `corepack yarn workspace @erp/app-auth typecheck` | Passed | No TypeScript errors. |
| `corepack yarn workspace @erp/ui typecheck` | Passed | No TypeScript errors after adding the UI TypeScript dev dependency. |
| `corepack yarn workspace @erp/app-charge-agreements test` | Passed | 1 Vitest test passed. |
| Reference Data root Vitest command | Passed | 18 tests passed. |
| Auth root Vitest command | Passed | 14 tests passed. |
| `node scripts\smoke-observability.mjs` | Passed | Observability smoke `status: ok`, 6 files checked. |
| `node scripts\runtime-devex.mjs --seed-file infrastructure\seeds\shared-platform-mvp-defaults.json` | Passed | Runtime devex `status: ok`; seed, owners, bootstrap, reset scopes, local-only validation passed. |
| `node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json` | Blocked | `passed: 9`, `blocked: 3`, `failed: 0`; Docker/live service availability, live provider verification, and live seed apply blocked. |

## Failure Handling

Initial backend execution failed because `JAVA_HOME` was not set in the shell. The issue was corrected by setting `JAVA_HOME` to `.local-tools\jdk-21`; the Maven reactor then passed.

Initial `@erp/ui` typecheck failed because the workspace did not declare TypeScript. Added `typescript` to `packages/ui/package.json`, refreshed Yarn metadata, and reran successfully.

## Coverage Notes

No coverage percentage report is configured for the Maven or Vitest suites. The executed suites provide behavior coverage over domain rules, application-service ports, integration seams, frontend workflow surfaces, runtime evidence scripts, contract checks, auth checks, and observability smoke checks.
