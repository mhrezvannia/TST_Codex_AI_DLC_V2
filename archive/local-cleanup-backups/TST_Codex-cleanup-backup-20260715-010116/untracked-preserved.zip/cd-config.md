# CD Config - LinerCore Enterprise

## Source Context

This CD configuration consumes `ci-config`, `quality-gates`, unit `deployment-architecture`, and unit `cicd-pipeline` artifacts. Construction CI is GitHub Actions quality gates; production deployment infrastructure and artifact repositories are not configured yet.

## Deployment Pipeline Decision

| Area | Decision |
|---|---|
| CD model | Continuous delivery, not automatic production deployment. |
| Source of truth | GitHub Actions CI evidence plus Operation deployment runbooks. |
| Environments | `local` and `ci-evidence` exist now; `staging` and `production` remain target environments pending cloud/IaC provisioning. |
| Artifact repositories | Deferred until deployment infrastructure chooses ECR, CodeArtifact, S3, or equivalent. |
| Production approval | Manual approval required before production promotion. |
| Live readiness | Required before staging/production promotion; current local evidence is blocked without Docker/live services. |

## Promotion Flow

```text
Pull Request
  -> GitHub Actions quality gates
  -> merge to main after green offline gates
  -> release candidate evidence bundle
  -> staging deployment when target infrastructure exists
  -> smoke, contracts --live, seed apply, observability readiness
  -> manual production approval
  -> production deployment
  -> post-deploy smoke and monitoring review
```

## Gate Commands

CD promotion reuses the CI evidence from `quality-gates` and adds live checks when an environment exists:

```powershell
node scripts\verify-contract-providers.mjs --live --evidence-file artifacts\contracts-live-verification.json
node scripts\seed-local.mjs --seed-file infrastructure\seeds\shared-platform-mvp-defaults.json --summary-file artifacts\seed-apply-attempt.json
node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json
node scripts\smoke-observability.mjs
```

## Artifact Handling

Until artifact repositories are selected, the CD pipeline publishes evidence artifacts only:

- `artifacts/quality-gates/evidence.json`
- `artifacts/quality-gates/*.log`
- `artifacts/runtime-devex/report.json`
- `artifacts/readiness/local-readiness.json`
- `artifacts/contracts-live-verification.json`
- `artifacts/seed-apply-attempt.json`

Deployable service/frontend/container artifacts must be added once target runtime and registry decisions are made.
