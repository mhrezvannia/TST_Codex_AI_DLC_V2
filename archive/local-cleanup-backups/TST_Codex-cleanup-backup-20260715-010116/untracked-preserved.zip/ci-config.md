# CI Config - LinerCore Enterprise

## Source Context

This CI configuration consumes the construction unit `code-summary` artifacts plus `build-and-test-summary` and `build-test-results`. The existing workspace CI is GitHub Actions at `.github/workflows/quality-gates.yml`.

## Pipeline Tooling

| Decision | Value |
|---|---|
| CI tool | GitHub Actions |
| Runner | `self-hosted`, `on-prem`, `linux` |
| Trigger | Pull requests to `main` and manual `workflow_dispatch` |
| Dependency manager | Yarn 4.5.3 via Corepack |
| Java | Temurin 21 in CI; `.local-tools\jdk-21` for local Windows verification |
| Backend build | Maven reactor under `services/pom.xml` |
| Evidence artifacts | `artifacts/quality-gates`, `artifacts/runtime-devex`, `artifacts/readiness`, live contract/seed attempts |

## Workflow Shape

The workflow now:

1. Checks out the repository.
2. Sets up Java 21 with Maven cache.
3. Enables Corepack.
4. Installs frontend dependencies with `corepack yarn install --immutable`.
5. Runs `node scripts/run-quality-gates.mjs --all --evidence artifacts/quality-gates/evidence.json`.
6. Always writes runtime devex evidence to `artifacts/runtime-devex/report.json`.
7. Always writes local readiness evidence to `artifacts/readiness/local-readiness.json`.
8. Always uploads quality evidence and per-gate logs.

## Local Equivalence

Local developers can reproduce the CI gates with:

```powershell
corepack yarn install --mode=skip-build
$env:JAVA_HOME=(Resolve-Path .local-tools\jdk-21).Path
$env:Path="$env:JAVA_HOME\bin;$env:Path"
node scripts\run-quality-gates.mjs --all --evidence artifacts\quality-gates\evidence.json
node scripts\runtime-devex.mjs --seed-file infrastructure\seeds\shared-platform-mvp-defaults.json --evidence-file artifacts\runtime-devex\report.json
node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json
```

## Artifact Policy

CI uploads:

- `artifacts/quality-gates/evidence.json`
- `artifacts/quality-gates/*.log`
- `artifacts/runtime-devex/report.json`
- `artifacts/readiness/local-readiness.json`
- `artifacts/contracts-live-verification.json`
- `artifacts/seed-apply-attempt.json`

Live-only readiness may be blocked on a runner without Docker or live services; the readiness evidence must preserve that as blocked evidence, not a passed gate.
