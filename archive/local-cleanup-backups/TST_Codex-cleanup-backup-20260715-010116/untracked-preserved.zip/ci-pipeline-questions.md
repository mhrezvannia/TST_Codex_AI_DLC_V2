# CI Pipeline Questions - LinerCore Enterprise

## Source Context

These questions consume `code-summary`, `build-and-test-summary`, and `build-test-results`. Existing evidence indicates GitHub Actions is already present and adequate for Construction quality gates.

## Questions And Assumed Answers

| Question | Assumed answer | Rationale |
|---|---|---|
| What CI tool is in use? | GitHub Actions | `.github/workflows/quality-gates.yml` exists and now runs the quality gate aggregator. |
| What branch strategy is used? | Pull requests into `main` | The existing workflow triggers on `pull_request` to `main`. |
| What quality gates are required before merge? | Package policy, backend domain purity, contracts, seed/runtime devex, observability smoke, frontend typechecks/tests, backend Maven tests. | These match `build-and-test-summary` and `build-test-results`. |
| What artifact repositories are used? | None configured in Construction CI. | No deployable artifact publishing exists yet; Operation deployment pipeline should decide ECR/CodeArtifact/S3. |
| Should live runtime checks block PRs? | Not yet. | Current workstation evidence shows Docker/live services are unavailable; CI should preserve blocked evidence and Operation should validate live runtime. |

## Open Confirmation Items

- Confirm whether the self-hosted runner has Docker and service ports available for full live readiness.
- Confirm artifact repository targets before Operation deployment pipeline work.
- Confirm whether dependency/SAST scanners are available in CI, or whether security gates remain current policy/auth/secret-safety checks until scanners are provisioned.
