# Code Generation Plan - booking-confirmed-journey-integration

## Plan Context

Unit: `booking-confirmed-journey-integration`

Scope: Implement the Booking-to-CMM `booking.confirmed` event seam. Booking must publish complete confirmation evidence through its outbox; CMM must consume the event contract, deduplicate by event/revision, reconcile booking revisions, and create or update journeys without deriving movement status or calculating pricing/D&D.

Test strategy: Comprehensive Java unit tests for producer payload shape, CMM consumer deduplication/reconciliation, stale revision handling, reference validation, auth denial, and outbox evidence. Contract catalog validation remains green.

## Story-To-Step Traceability

| Story or requirement | Plan steps |
|---|---|
| US-BKG-005 - Confirmed booking publishes evidence | Step 1, Step 2, Step 6 |
| US-BKG-006 - Backward-compatible `booking.confirmed` contract | Step 2, Step 5, Step 6 |
| US-CMM-001 - Consume `booking.confirmed` and reconcile journey | Step 3, Step 4, Step 6 |
| US-CMM-002 - Derive expected movements from booking route | Step 3, Step 4, Step 6 |

## Sequential Implementation Steps

- [x] Step 1: Inventory existing Booking outbox, event contract, and CMM journey seams.
  - Confirm `BookingEventMapper`, Avro/example/message-pact fixtures, `ContainerMovementApplicationService`, domain journey state, repository and idempotency ports.

- [x] Step 2: Harden the Booking confirmed event payload.
  - Preserve existing required fields and add backward-compatible container/equipment journey metadata where needed.
  - Keep producer identity, schema version, deduplication key, correlation id, booking revision, and route fields explicit.

- [x] Step 3: Add typed CMM `BookingConfirmedEvent` ingestion model.
  - Validate event type, schema version, source, event id, idempotency key, booking id, revision, route locations, and correlation id.

- [x] Step 4: Implement CMM consumer/reconciliation behavior.
  - Deduplicate by event id/idempotency key, reject or ignore stale revisions, create first journey from booking route, reconcile newer revisions, and publish CMM status evidence.
  - Do not derive movement status from the booking event.

- [x] Step 5: Update contract examples/schema for backward-compatible metadata.
  - Keep catalog validation green.

- [x] Step 6: Add focused Java tests.
  - Cover producer payload shape, happy-path journey creation, duplicate replay, stale revision handling, newer revision reconciliation, denied consumer identity, inactive route references, and contract validation.

- [x] Step 7: Run verification commands and fix failures.
  - Run targeted Booking/CMM Maven tests.
  - Run full services Maven reactor because CMM domain/repository contracts are touched.
  - Run contract catalog validation and validator tests.

- [x] Step 8: Write `code-summary.md` and mark this plan complete.

## Implementation Guardrails

- Booking must not write CMM persistence directly.
- CMM must not calculate pricing, D&D, or movement status from `booking.confirmed`.
- Duplicate and stale events must be auditable and must not create duplicate journeys.
- Correlation, idempotency, schema version, producer/consumer identity, and booking revision must be preserved in tests.
