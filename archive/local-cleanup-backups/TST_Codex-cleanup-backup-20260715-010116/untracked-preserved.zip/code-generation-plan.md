# Code Generation Plan - enterprise-seed-migrations-devex

## Plan Context

Unit: `enterprise-seed-migrations-devex`

Scope: Implement practical local runtime/devex evidence for logical database owner provisioning, deterministic seed validation/application, reset-scope metadata, migration target detection, no-secret fixture scanning, and repeatable developer commands.

Test strategy: Node unit tests for runtime-devex report generation, owner uniqueness, migration target existence, reset-scope safety, bootstrap coverage, seed validation, and existing local/script smoke checks.

## Story-To-Step Traceability

| Story or requirement | Plan steps |
|---|---|
| US-SP-003 - Platform roles and permissions | Step 3, Step 5 |
| US-CHG-005 - Pricing/agreement seed support | Step 1, Step 4, Step 5 |
| US-BKG-004 - Booking validation fixture support | Step 3, Step 4, Step 5 |
| US-RUN-001 - Local runtime setup | Step 1, Step 2, Step 5 |
| US-RUN-002 - Repeatable setup/reset | Step 2, Step 4, Step 5 |
| US-RUN-003 - Developer command documentation | Step 4, Step 5 |

## Sequential Implementation Steps

- [x] Step 1: Inventory current Compose, seed, environment, and migration assets.
  - Confirmed existing seed tooling, local env, Compose profiles, and the only current service-owned SQL migration target.

- [x] Step 2: Add local logical database/user bootstrap.
  - Added a PostgreSQL entrypoint bootstrap script for identity, reference data, pricing, booking, container movement, Keycloak, and runtime tools owners.
  - Wired the script and DB owner passwords into Compose/local env.

- [x] Step 3: Move seed-loader from dry-run to apply-ready local mode.
  - Removed `--dry-run` from Compose seed-loader and supplied in-network Identity and Reference Data service URLs.

- [x] Step 4: Add runtime-devex validation/report command.
  - Added `scripts/runtime-devex.mjs` with owner validation, migration target validation, reset scopes, seed fingerprint/count evidence, bootstrap coverage, and local-only fixture scanning.
  - Added package scripts and seed README command documentation.

- [x] Step 5: Add and run tests.
  - Added `scripts/runtime-devex.test.mjs`.
  - Fixed observability smoke profile parsing to handle services profiled for both `observability` and `full`.

## Implementation Guardrails

- Seed fixtures remain deterministic non-production evidence data.
- Runtime setup does not claim persistent service behavior that is not wired yet.
- Reset metadata is scoped to known local logical databases only.
- No cross-service SQL join or shared domain schema is introduced.
