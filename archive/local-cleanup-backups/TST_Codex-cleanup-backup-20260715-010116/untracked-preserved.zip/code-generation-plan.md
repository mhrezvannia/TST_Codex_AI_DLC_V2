# Code Generation Plan - enterprise-web-shell-and-workflows

## Plan Context

Unit: `enterprise-web-shell-and-workflows`

Scope: Extend the existing enterprise visual shell with reusable workflow surfaces that expose work queue, exception, and evidence state inside module pages without copying prototype business rules or moving domain decisions into the frontend.

Test strategy: Typecheck affected apps and run module UI tests.

## Sequential Implementation Steps

- [x] Step 1: Inventory existing app shells, Reference Data workbench, Charge Agreements workbench, and shared UI package.
- [x] Step 2: Add reusable workflow/evidence command-center component to `@erp/ui`.
- [x] Step 3: Wire the command center into Reference Data with permission/API/contract evidence.
- [x] Step 4: Wire the command center into Charge Agreements with runtime/capability/agreement workflow evidence.
- [x] Step 5: Run affected frontend typechecks and tests.
- [x] Step 6: Write code summary and mark complete.

## Guardrails

- The UI presents workflow evidence and exceptions only; it does not calculate pricing, D&D, movement status, or authorization.
- The first screen remains an operational application surface, not a landing page.
- Components use dense enterprise workflow layout and preserve responsive constraints.
