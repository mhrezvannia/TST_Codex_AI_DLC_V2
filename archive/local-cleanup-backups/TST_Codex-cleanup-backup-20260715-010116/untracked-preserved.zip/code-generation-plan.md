# Code Generation Plan - movement-status-booking-integration

## Plan Context

Unit: `movement-status-booking-integration`

Scope: Implement Booking-side consumption of `containermovement.status` events with validation, deduplication, staleness handling, lifecycle evidence updates, and D&D trigger input evidence without making Booking derive movement status or making CMM decide D&D relevance.

Test strategy: Java unit tests for event validation, happy-path lifecycle evidence, duplicate replay, stale sequence handling, denied consumer identity, and D&D trigger input recording; keep CMM producer and contract validation green.

## Sequential Implementation Steps

- [x] Step 1: Inventory CMM status producer and Booking lifecycle seams.
- [x] Step 2: Add typed Booking movement-status event ingestion model.
- [x] Step 3: Add Booking domain method for recording observed movement status evidence.
- [x] Step 4: Add Booking application-service consumer behavior with auth, idempotency, stale sequence checks, and D&D trigger input evidence.
- [x] Step 5: Add focused Java tests.
- [x] Step 6: Run targeted and full verification.
- [x] Step 7: Write code summary and mark complete.

## Guardrails

- Booking stores CMM-provided status; it does not derive movement status.
- CMM status events do not calculate D&D or create charges.
- Duplicate and stale events do not create duplicate lifecycle evidence.
- Correlation, idempotency, producer identity, and sequence are preserved.
