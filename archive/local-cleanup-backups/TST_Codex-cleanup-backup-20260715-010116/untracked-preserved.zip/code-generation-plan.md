# Code Generation Plan - Observability Quality Operation Readiness

## Source Context

This plan consumes the unit functional design, business rules, domain entities, NFR designs, deployment architecture, and the existing repository scripts for local runtime, quality gates, contracts, seeds, and observability smoke checks.

## Implementation Plan

1. Extend local readiness from a flat command runner into a normalized evidence bundle.
2. Preserve existing CLI behavior while adding `EvidenceRun`, `EvidenceItem`, freshness key, quality gate, blocker, and Operation handoff sections.
3. Add fail-closed runtime and observability quality gates to the workspace gate runner.
4. Keep evidence redacted so command summaries do not leak tokens, authorization headers, passwords, or secrets.
5. Cover the new behavior with focused script tests and run the full script test suite.

## Files Planned

| File | Change |
|---|---|
| `scripts/local-readiness.mjs` | Add normalized readiness evidence, freshness metadata, blockers, redaction, and Operation handoff output. |
| `scripts/local-readiness.test.mjs` | Assert evidence item generation, quality gate decisions, freshness keys, compatibility fields, and redaction. |
| `scripts/run-quality-gates.mjs` | Add required runtime devex, local readiness evidence, and observability smoke gates; classify runtime/observability paths. |
| `scripts/run-quality-gates.test.mjs` | Assert runtime and observability scope selection. |
| `artifacts/readiness/local-readiness.json` | Generated local evidence run showing current runtime readiness state. |

## Verification Plan

| Command | Purpose |
|---|---|
| `node --test scripts\local-readiness.test.mjs scripts\run-quality-gates.test.mjs scripts\runtime-devex.test.mjs scripts\smoke-observability.test.mjs` | Targeted evidence and gate verification. |
| `node --test scripts\*.test.mjs` | Full script regression suite. |
| `node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json` | Exercise the CLI evidence bundle path and write a machine-readable readiness artifact. |

## Expected Local Result

The CLI readiness command is expected to return `blocked`, not `failed`, when Docker/live services are unavailable. That preserves partial evidence and prevents fake completion while allowing offline checks to pass.
