# Code Generation Plan - dnd-pricing-integration

## Plan Context

Unit: `dnd-pricing-integration`

Scope: Implement the Booking-to-Charge D&D pricing handoff. Booking owns D&D-relevant movement boundary trigger evidence and stores returned result snapshots; Charge remains owner of free-time, chargeable-day, and rate calculation.

Test strategy: Java unit tests for Booking result storage/manual fallback and adapter success/denied classification, plus contract catalog validation and full services reactor tests.

## Sequential Implementation Steps

- [x] Step 1: Inventory Booking movement/D&D trigger evidence and Charge D&D contract surface.
- [x] Step 2: Add Booking D&D pricing port/result outcome model.
- [x] Step 3: Add fakeable Charge D&D pricing adapter and DTOs.
- [x] Step 4: Add Booking service method to request D&D pricing and store returned evidence.
- [x] Step 5: Add tests for successful D&D snapshot, manual fallback, and denied adapter classification.
- [x] Step 6: Run targeted Booking tests, contract validation, and full services Maven reactor.
- [x] Step 7: Write code summary and mark complete.

## Guardrails

- Booking must not calculate D&D free time, chargeable days, rates, or totals.
- CMM must not decide D&D relevance.
- Charge returned evidence is stored compactly in Booking, with manual/failure outcomes routed to Booking exceptions.
- The concrete HTTP transport remains outside this bounded application-service seam.
