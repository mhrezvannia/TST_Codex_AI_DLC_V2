# Code Generation Plan - booking-charge-pricing-integration

## Plan Context

Unit: `booking-charge-pricing-integration`

Scope: Implement the Booking-to-Charge pricing seam. Booking prepares an idempotent, correlated pricing request, calls Charge through a typed port/client, classifies success/failure/manual fallback responses, and stores an auditable pricing snapshot without taking ownership of Charge calculation rules.

Test strategy: Comprehensive. This plan includes Java unit tests for request building, HTTP/client adapter behavior, failure classification, idempotency/correlation propagation, and Booking snapshot handoff. It also keeps existing OpenAPI/Pact contract validation green.

## Story-To-Step Traceability

| Story or requirement | Plan steps |
|---|---|
| US-CHG-002 - Customer agreement pricing | Step 1, Step 2, Step 3, Step 5 |
| US-CHG-003 - Manual pricing fallback | Step 3, Step 4, Step 5 |
| US-CHG-004 - Pricing audit evidence | Step 2, Step 3, Step 5 |
| US-BKG-002 - Booking pricing request | Step 1, Step 2, Step 4, Step 5 |
| US-UI-002 - Booking/charge workflow support | Step 6, Step 7 |

## Sequential Implementation Steps

- [x] Step 1: Inventory existing Booking and Charge pricing seams.
  - Confirm `BookingApplicationService`, `PricingPort`, `PricingSnapshot`, Charge pricing APIs, contracts, and tests.
  - Traceability: US-BKG-002, US-CHG-002.

- [x] Step 2: Add typed pricing request and response DTOs for the seam.
  - Add Booking-owned request builder context carrying booking id, customer, lane, equipment, quantities, idempotency key, request hash, actor/service subject, and correlation id.
  - Add response snapshot/failure DTOs that do not encode Charge calculation rules.
  - Traceability: US-CHG-002, US-CHG-004.

- [x] Step 3: Implement Charge pricing client adapter.
  - Add a fakeable client/adapter using Java standard HTTP types or an interface-backed adapter matching project dependencies.
  - Preserve service auth placeholder, correlation, idempotency, timeout classification, and non-retry 4xx behavior.
  - Traceability: US-CHG-002, US-CHG-003, US-CHG-004.

- [x] Step 4: Integrate Booking pricing snapshot handoff.
  - Update Booking pricing port implementation/test fakes so successful Charge responses produce pricing snapshots and manual/failure states are explicit.
  - Do not calculate prices in Booking.
  - Traceability: US-BKG-002, US-CHG-003.

- [x] Step 5: Add comprehensive Java tests.
  - Cover successful pricing call, manual fallback response, transient failure classification, denied/auth failure, idempotency/correlation propagation, request hash stability, and Booking snapshot storage.
  - Traceability: all unit stories.

- [x] Step 6: Keep frontend/UI out of this unit unless an existing surface requires a small compatibility update.
  - UI behavior should consume future Booking/Charge APIs; no new `apps/booking` or pricing-rule UI is added here.
  - Traceability: US-UI-002.

- [x] Step 7: Run verification commands and fix failures.
  - Run targeted Booking/Charge Maven tests.
  - Run full services Maven reactor if shared contracts or ports change.
  - Run contract catalog validation and validator tests.
  - Traceability: all unit stories.

- [x] Step 8: Write the code summary and mark this plan complete.
  - Produce `code-summary.md` under this unit's `code-generation` record directory.
  - Summarize files changed, implementation decisions, test coverage, command results, and deviations.
  - Traceability: all unit stories.

## Implementation Guardrails

- Booking must not calculate Charge pricing.
- Charge must not mutate Booking lifecycle.
- No cross-service database joins.
- All request/response/failure paths preserve idempotency and correlation.
- Auth/validation failures are not retried as transient pricing failures.
