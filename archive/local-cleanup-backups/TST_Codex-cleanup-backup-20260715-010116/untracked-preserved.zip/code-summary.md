# Code Summary - booking-charge-pricing-integration

## Unit

`booking-charge-pricing-integration`

## Implementation

- Extended Booking's `PricingPort` from a request-id-only seam to a typed `PricingRequestResult` outcome model covering pending async pricing, priced snapshots, manual fallback, transient failure, denied service identity, and validation failure.
- Updated `BookingApplicationService.requestPricing` so it always records the pricing request id, stores immediate Charge quote snapshots when available, and converts manual/failure outcomes into visible Booking exception evidence without calculating Charge pricing.
- Added a fakeable Charge pricing adapter package under Booking application-service:
  - `ChargePricingPortAdapter`
  - `ChargePricingClient`
  - request/response/line item DTOs
  - client exception and failure classification enums
- The adapter builds deterministic request hashes and pricing request ids from Booking state plus idempotency key, preserves correlation/idempotency in the outbound request, maps Charge line item evidence into Booking snapshot metadata, and treats denied/validation failures separately from transient outages.

## Files Changed

- `services/booking-service/application-service/src/main/java/com/linercore/platform/booking/applicationservice/BookingApplicationService.java`
- `services/booking-service/application-service/src/main/java/com/linercore/platform/booking/applicationservice/port/PricingPort.java`
- `services/booking-service/application-service/src/main/java/com/linercore/platform/booking/applicationservice/port/PricingOutcome.java`
- `services/booking-service/application-service/src/main/java/com/linercore/platform/booking/applicationservice/port/PricingRequestResult.java`
- `services/booking-service/application-service/src/main/java/com/linercore/platform/booking/applicationservice/pricing/*`
- `services/booking-service/application-service/src/test/java/com/linercore/platform/booking/applicationservice/BookingApplicationServiceTest.java`
- `services/booking-service/application-service/src/test/java/com/linercore/platform/booking/applicationservice/pricing/ChargePricingPortAdapterTest.java`

## Verification

- `.\.local-tools\apache-maven\bin\mvn.cmd -f services\booking-service\pom.xml test` - passed, 12 Booking tests.
- `node scripts\validate-contract-catalog.mjs` - passed, 13 contracts, overall green.
- `node --test scripts\validate-contract-catalog.test.mjs` - passed, 12 validator tests.
- `.\.local-tools\apache-maven\bin\mvn.cmd -f services\pom.xml test` - passed, 31 Maven modules.

## Deviations

- No frontend work was added in this unit. The approved plan kept UI changes out unless an existing surface required compatibility work, and the current changes are backend application-service seam work only.
- No concrete HTTP transport was added. The implemented adapter is interface-backed and fakeable, matching the current service dependency style and giving executable behavior without introducing premature runtime wiring.

## Completion

All approved plan steps are complete for this unit.
