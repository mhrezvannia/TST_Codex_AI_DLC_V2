# Code Summary - container-movement-domain

## Unit Scope

Implemented the Container Movement Management domain foundation for journey creation, expected movements, movement capture, DCSA-aligned validation evidence, ordering/deduplication, status derivation, movement history, and status-event evidence. The implementation preserves the boundary that CMM does not mutate Booking lifecycle, decide D&D relevance, or calculate pricing/D&D.

## Files Created Or Modified

| Path | Summary |
|---|---|
| `services/container-movement-service/domain-core/src/main/java/com/linercore/platform/containermovement/domain/model/ExpectedMovement.java` | Added required-field validation for expected movement sequence, event type, and location. |
| `services/container-movement-service/domain-core/src/main/java/com/linercore/platform/containermovement/domain/model/MovementEvent.java` | Added fail-fast validation for event type, dedupe key, and correlation id. |
| `services/container-movement-service/domain-core/src/main/java/com/linercore/platform/containermovement/domain/outbox/MovementStatusEventMapper.java` | Enriched status event payload with source, idempotency key, movementStatus, sequenceNumber, statusReason, and lastKnownLocationId to align with the Avro fixture. |
| `services/container-movement-service/domain-core/src/test/java/com/linercore/platform/containermovement/domain/outbox/MovementStatusEventMapperTest.java` | Added assertions for contract-facing movement-status payload fields. |
| `services/container-movement-service/application-service/src/main/java/com/linercore/platform/containermovement/applicationservice/ContainerMovementApplicationService.java` | Added application use cases for create journey and capture movement with authorization, idempotency, reference validation, audit, persistence, and outbox seams. |
| `services/container-movement-service/application-service/src/main/java/com/linercore/platform/containermovement/applicationservice/command/*.java` | Added create journey and capture movement command records. |
| `services/container-movement-service/application-service/src/main/java/com/linercore/platform/containermovement/applicationservice/port/*.java` | Added fakeable repository, authorization, reference validation, id generation, idempotency, audit, and outbox ports. |
| `services/container-movement-service/application-service/src/test/java/com/linercore/platform/containermovement/applicationservice/ContainerMovementApplicationServiceTest.java` | Added tests for journey creation, idempotent replay, movement capture/status event, inactive reference failure, and authorization denial. |
| `scripts/validate-contract-catalog.mjs` | Removed `services/container-movement-service` from out-of-scope runtime guard because this enterprise unit now owns that service. |
| `scripts/validate-contract-catalog.test.mjs` | Retained guardrail coverage by asserting `apps/container-movement` remains out of scope. |
| `aidlc/spaces/default/intents/260708-linercore-enterprise/construction/container-movement-domain/code-generation/code-generation-plan.md` | Marked all implementation and verification steps complete. |

## Key Implementation Decisions

- CMM application service exposes ports rather than concrete persistence or HTTP clients, matching the Booking and Charge Agreement service foundations.
- Idempotency replay returns the existing journey/current journey state without duplicating outbox events.
- Status events are emitted on journey creation and movement capture as evidence for downstream Booking integration, but CMM does not call Booking or D&D services directly.
- Reference validation is limited to location IDs for this unit; broader reference consumption remains a port-level integration seam.
- The contract-catalog guardrail still blocks UI/runtime apps outside the current unit while allowing the now in-scope CMM service.

## Test Coverage

| Command | Result |
|---|---|
| `$env:JAVA_HOME=(Resolve-Path '.local-tools\\jdk-21').Path; .\\.local-tools\\apache-maven\\bin\\mvn.cmd -f services\\container-movement-service\\pom.xml test` | Passed: 9 CMM tests, 0 failures. |
| `node scripts\\validate-contract-catalog.mjs` | Passed: contract health green, 13 contracts. |
| `node --test scripts\\validate-contract-catalog.test.mjs` | Passed: 12 contract validator tests. |
| `$env:JAVA_HOME=(Resolve-Path '.local-tools\\jdk-21').Path; .\\.local-tools\\apache-maven\\bin\\mvn.cmd -f services\\pom.xml test` | Passed: full services reactor, 31 modules, build success. |

## Deviations

- No container/API module was added for CMM in this unit. The plan called for domain and application-service ownership first; runtime/API wiring is deferred to a later CMM integration/API unit.
- No UI changes were made for CMM because there is no existing `apps/container-movement` surface and the contract guardrail still blocks that app until its owning UI unit.

## Traceability

| Story | Implementation Evidence |
|---|---|
| US-CMM-001 - Create journey | `ContainerMovementApplicationService.createJourney`, `ContainerJourney.create`, application tests. |
| US-CMM-002 - Derive expected movements | `ContainerJourney.create`, `ExpectedMovement` validation, domain tests. |
| US-CMM-003 - Capture movement events | `ContainerMovementApplicationService.captureMovement`, `MovementEvent` validation, application/domain tests. |
| US-CMM-004 - Consume reference changes | `ReferenceValidationPort` seam and inactive-location failure test. |
| US-CMM-005 - Derive movement status | `ContainerJourney.capture`, status derivation tests, status event tests. |
| US-CMM-006 - Publish movement status | `MovementStatusEventMapper`, `OutboxRepository`, contract validator and mapper tests. |
| US-UI-004 - CMM UI support | Application ports expose future UI/API seams without adding an out-of-scope UI app. |
