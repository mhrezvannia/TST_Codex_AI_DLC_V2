# Code Summary - booking-confirmed-journey-integration

## Unit

`booking-confirmed-journey-integration`

## Implementation

- Hardened `booking.confirmed` producer evidence by adding `containerId` metadata to the Booking outbox payload.
- Updated the Avro schema and contract example with a backward-compatible `containerId` field using an empty-string default.
- Added a typed CMM `BookingConfirmedEvent` ingestion model that validates event type, schema version, source, event id, idempotency key, booking id, revision, route locations, equipment, timestamp, and correlation id.
- Extended `ContainerJourney` with `bookingRevision` and reconciliation behavior so newer booking revisions can update expected movements without deriving movement status.
- Extended `JourneyRepository` with `findByBookingId` to support reconciliation without cross-service database access.
- Added `ContainerMovementApplicationService.consumeBookingConfirmed` to:
  - enforce consumer authorization;
  - deduplicate by idempotency key;
  - reject inactive booking route references;
  - ignore stale revisions without publishing duplicate status evidence;
  - create first journeys from confirmed bookings;
  - reconcile newer booking revisions and emit CMM status evidence.

## Files Changed

- `contracts/avro/booking.confirmed.avsc`
- `contracts/examples/booking.confirmed.example.json`
- `services/booking-service/domain-core/src/main/java/com/linercore/platform/booking/domain/outbox/BookingEventMapper.java`
- `services/booking-service/domain-core/src/test/java/com/linercore/platform/booking/domain/outbox/BookingEventMapperTest.java`
- `services/container-movement-service/domain-core/src/main/java/com/linercore/platform/containermovement/domain/model/ContainerJourney.java`
- `services/container-movement-service/domain-core/src/test/java/com/linercore/platform/containermovement/domain/model/ContainerJourneyTest.java`
- `services/container-movement-service/application-service/src/main/java/com/linercore/platform/containermovement/applicationservice/event/BookingConfirmedEvent.java`
- `services/container-movement-service/application-service/src/main/java/com/linercore/platform/containermovement/applicationservice/ContainerMovementApplicationService.java`
- `services/container-movement-service/application-service/src/main/java/com/linercore/platform/containermovement/applicationservice/port/JourneyRepository.java`
- `services/container-movement-service/application-service/src/test/java/com/linercore/platform/containermovement/applicationservice/ContainerMovementApplicationServiceTest.java`

## Verification

- `.\.local-tools\apache-maven\bin\mvn.cmd -f services\booking-service\pom.xml test` - passed, 17 Booking tests across domain/application modules.
- `.\.local-tools\apache-maven\bin\mvn.cmd -f services\container-movement-service\pom.xml test` - passed, 16 CMM tests across domain/application modules.
- `node scripts\validate-contract-catalog.mjs` - passed, 13 contracts, overall green.
- `node --test scripts\validate-contract-catalog.test.mjs` - passed, 12 validator tests.
- `.\.local-tools\apache-maven\bin\mvn.cmd -f services\pom.xml test` - passed, 31 Maven modules.

## Deviations

- No Kafka runtime adapter was added. The current repository service style is still application-service/domain focused, so this unit added a typed consumer seam and executable reconciliation behavior without introducing premature transport wiring.
- The confirmed event now carries optional `containerId`. When absent, CMM derives a deterministic equipment journey id from booking id and equipment type so older events remain consumable.

## Completion

All approved plan steps are complete for this unit.
