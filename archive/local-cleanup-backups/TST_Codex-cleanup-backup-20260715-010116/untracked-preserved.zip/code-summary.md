# Code Summary - enterprise-web-shell-and-workflows

## Unit

`enterprise-web-shell-and-workflows`

## Implementation

- Added `WorkflowCommandCenter` to `packages/ui/src/index.tsx`.
- Added shared queue/evidence/exception item types for module workflow surfaces.
- Wired the command center into `apps/reference-data/app/ReferenceDataWorkbench.tsx` with permission state, contract catalog counts, loaded record counts, and API fallback exceptions.
- Wired the command center into `apps/charge-agreements/app/ChargeAgreementWorkbench.tsx` with agreement approval, pricing lookup, backend status, capability counts, and suspended/fallback exception evidence.

## Verification

- `yarn workspace @erp/app-reference-data typecheck` - passed.
- `yarn workspace @erp/app-charge-agreements typecheck` - passed.
- `yarn workspace @erp/app-charge-agreements test` - passed, 1 test.
- `node .\node_modules\vitest\vitest.mjs --root . run apps\reference-data\app\page.test.tsx apps\reference-data\lib\reference-data.test.ts apps\reference-data\lib\service-clients.test.ts apps\reference-data\lib\contract-catalog.test.ts` - passed, 18 tests.

## Deviations

- `yarn workspace @erp/ui typecheck` could not run because that workspace command could not resolve `tsc` in this environment. The affected app typechecks compiled the shared UI import successfully.
- `yarn workspace @erp/app-reference-data test` could not resolve `vitest`; the same tests were run successfully through the root Vitest binary.

## Completion

All plan steps are complete for this unit.
