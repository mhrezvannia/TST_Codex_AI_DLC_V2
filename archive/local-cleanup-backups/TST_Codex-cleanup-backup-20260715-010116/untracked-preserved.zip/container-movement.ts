export type MovementEventType = "PLANNED_DEPARTURE" | "ACTUAL_DEPARTURE" | "ESTIMATED_ARRIVAL" | "ACTUAL_ARRIVAL" | "DELIVERED" | "EXCEPTION";
export type MovementStatus = "PLANNED" | "IN_TRANSIT" | "ARRIVED" | "DELIVERED" | "EXCEPTION";

export type JourneyView = {
  id: string;
  bookingId: string;
  bookingRevision: number;
  containerId: string;
  status: MovementStatus;
  expectedMovements: Array<{ sequence: string; expectedEventType: MovementEventType; locationId: string }>;
  history: Array<{
    eventId: string;
    eventType: MovementEventType;
    containerId: string;
    locationId: string;
    eventTime: string;
    dedupeKey: string;
    correlationId: string;
  }>;
  updatedAt: string;
};

export const fallbackJourneys: JourneyView[] = [
  {
    id: "demo-journey",
    bookingId: "demo-booking",
    bookingRevision: 1,
    containerId: "CONT-DEMO-001",
    status: "PLANNED",
    expectedMovements: [
      { sequence: "1", expectedEventType: "PLANNED_DEPARTURE", locationId: "loc-origin" },
      { sequence: "2", expectedEventType: "ESTIMATED_ARRIVAL", locationId: "loc-destination" }
    ],
    history: [],
    updatedAt: new Date(0).toISOString()
  }
];

export function movementServiceUrl() {
  return (process.env.CONTAINER_MOVEMENT_SERVICE_URL ?? "http://localhost:8086").replace(/\/+$/, "");
}

export async function proxyJson(path: string, init: RequestInit, correlationId: string) {
  try {
    const response = await fetch(`${movementServiceUrl()}${path}`, {
      ...init,
      headers: {
        "content-type": "application/json",
        "x-correlation-id": correlationId,
        ...(init.headers ?? {})
      },
      signal: AbortSignal.timeout(5000)
    });
    const data = await safeJson(response);
    return Response.json(data, { status: response.status });
  } catch (error) {
    return Response.json({
      error: "container movement service unavailable",
      detail: error instanceof Error ? error.message : String(error),
      correlationId
    }, { status: 503 });
  }
}

export function correlationId(request: Request, prefix = "movement-ui") {
  return request.headers.get("x-correlation-id") ?? `${prefix}-${crypto.randomUUID()}`;
}

async function safeJson(response: Response) {
  const text = await response.text();
  if (!text) {
    return null;
  }
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}
