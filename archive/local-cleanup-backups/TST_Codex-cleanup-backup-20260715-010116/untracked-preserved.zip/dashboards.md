# Dashboards - LinerCore Enterprise

## Source Context

This dashboard plan consumes `performance-design`, `security-design`, `reliability-design`, `monitoring-design`, and `infrastructure-services`. Existing local assets are under `infrastructure/observability/grafana/`.

## Dashboard Inventory

| Dashboard | Source | Signals |
|---|---|---|
| Shared Platform Overview | `infrastructure/observability/grafana/dashboards/shared-platform-overview.json` | Event freshness, service health, publication status, readiness signals. |
| Contract/Readiness Evidence | `artifacts/quality-gates/evidence.json`, `artifacts/readiness/local-readiness.json` | Quality gate status, blockers, owners, command freshness. |
| Runtime Devex | `artifacts/runtime-devex/report.json` | DB owner validation, reset scopes, bootstrap, migration target, seed fingerprint. |
| Future service dashboard | Pending live instrumentation | Request latency, traffic, errors, saturation per Identity, Reference Data, Charge, Booking, CMM. |

## Layout

- Top band: environment, git ref, readiness decision, blocker count.
- Service row: Identity, Reference Data, Charge, Booking, CMM, Enterprise Web health.
- Event row: Kafka publication attempts, outbox lag, event freshness, schema compatibility.
- Security row: authorization decisions, denied-path count, audit writer health.
- Runtime row: seed status, migration status, database owner validation, profile readiness.

## Validation

`node scripts\smoke-observability.mjs` passed and confirmed required dashboard/provisioning files exist. Live panel data requires running the Compose observability profile.
