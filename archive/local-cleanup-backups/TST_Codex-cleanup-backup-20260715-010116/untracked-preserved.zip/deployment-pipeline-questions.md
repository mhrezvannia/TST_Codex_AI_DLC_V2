# Deployment Pipeline Questions - LinerCore Enterprise

## Source Context

These questions consume `ci-config`, `quality-gates`, unit `deployment-architecture`, and unit `cicd-pipeline` artifacts. Current answers are conservative assumptions because cloud runtime and artifact repositories are not configured.

## Questions And Assumptions

| Question | Assumed answer | Follow-up required |
|---|---|---|
| What deployment strategy should be used? | Continuous delivery with manual production approval. | Confirm whether staging should use rolling, blue/green, or canary once runtime target exists. |
| What environments are required? | Local, CI evidence, staging, production. | Define staging/production infrastructure and secrets. |
| What approval workflow applies to production? | Manual approval after staging gates pass. | Name approver group and evidence retention policy. |
| What rollback procedure applies now? | Git revert plus regenerated evidence for repository changes. | Add runtime rollback commands after artifact/runtime target is selected. |
| What feature flag platform is preferred? | AWS AppConfig candidate; CloudWatch Evidently only for experiments. | Confirm platform and flag lifecycle policy. |
| What artifact repositories are used? | Not configured. | Choose ECR/CodeArtifact/S3 or equivalent before deployment execution. |

## Blocking Decisions

- Target runtime platform for Java services and Enterprise Web.
- Artifact repository and tagging convention.
- Whether CI runners can run Docker Compose services for live readiness.
- Production approval owners.
- SAST/DAST/dependency scanning tooling for promotion gates.
