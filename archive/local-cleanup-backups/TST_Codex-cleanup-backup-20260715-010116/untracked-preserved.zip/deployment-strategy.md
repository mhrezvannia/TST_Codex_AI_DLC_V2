# Deployment Strategy - LinerCore Enterprise

## Source Context

This strategy consumes `ci-config`, `quality-gates`, unit `deployment-architecture`, and unit `cicd-pipeline` artifacts. Unit designs separate local runtime from production topology and defer production deployment, scaling, backup, DR, and incident response details to Operation.

## Strategy

| Component | First Operation strategy | Reason |
|---|---|---|
| Repository tooling, contracts, runtime evidence | Promote by merge and evidence bundle publication. | These are repo-native scripts/artifacts, not runtime services. |
| Enterprise Web apps | Rolling or blue/green after hosting target is selected. | Current code is app-level UI; hosting target is not configured. |
| Java services | Rolling or blue/green after container/runtime target is selected. | Current services pass reactor tests but lack production deployment topology. |
| Databases/migrations | Expand-contract only. | Service-owned persistence is not fully wired; destructive migration rollback is unsafe. |
| Kafka/event seams | Backward-compatible schema evolution only. | Avro/AsyncAPI/message-pact compatibility must remain green. |

## Environment Promotion Gates

| Environment | Entry gate | Exit gate |
|---|---|---|
| Local | Offline quality gates pass. | Local readiness evidence generated, blockers understood. |
| CI evidence | Pull request quality gates pass. | Evidence artifacts uploaded and retained. |
| Staging | Target infrastructure, registry, secrets, and service endpoints configured. | Live contracts, seed apply, smoke, observability, and rollback rehearsal pass. |
| Production | Manual approval, staging green, rollback runbook reviewed. | Post-deploy smoke, metrics, logs, traces, and alert review pass. |

## Feature Flags

Use feature flags for incomplete workflows and risky UI/service behavior once a flag provider is selected:

- Candidate AWS path: AppConfig for operational flags.
- Experimentation path: CloudWatch Evidently only if business experiments are required.
- Do not put secrets, credentials, or environment URLs into flags.
- Every release flag must have owner, expiry, and cleanup task.

## Deployment Health Signals

- CI quality gate aggregate status.
- Live provider contract status.
- Seed apply result and deterministic seed fingerprint.
- Local/runtime readiness evidence decision.
- Observability smoke status, dashboard availability, metrics/logs/traces presence.
- Service-specific denied-path and idempotency tests.
