# Environment Inventory - LinerCore Enterprise

## Source Context

This inventory consumes unit `deployment-architecture`, unit `infrastructure-services`, and Operation `cd-config`. No AWS environment IaC or deployed cloud stacks are present yet; the provisioned environment surface is local Docker Compose metadata plus CI evidence artifacts.

## Current Environments

| Environment | Status | Evidence |
|---|---|---|
| Local profile `core` | Defined | Runtime metadata includes Postgres, Keycloak, Kafka, Schema Registry. |
| Local profile `app` | Defined | Runtime metadata includes service/front-end routes and nginx. |
| Local profile `observability` | Defined | Runtime metadata includes Prometheus, Grafana, Jaeger, OTel Collector, Elasticsearch, Kibana. |
| Local profile `full` | Defined, not live-running in this session | `node scripts\local-runtime.mjs plan --profile full --dry-run` returned `status: ok`. |
| CI evidence | Defined | GitHub Actions quality-gates workflow uploads quality, runtime-devex, readiness, contract, and seed evidence. |
| Staging | Not provisioned | CD config requires target infrastructure and registry decisions first. |
| Production | Not provisioned | CD config requires manual approval, target infrastructure, artifact registry, secrets, monitoring, backup, DR, and rollback strategy. |

## Local Full Profile Services

| Service | Purpose |
|---|---|
| `postgres` | Logical databases/users for identity, reference data, pricing, booking, CMM, Keycloak, tools. |
| `keycloak` | Local identity provider and realm/client/user/role bootstrap. |
| `kafka` | Event transport for reference data, Booking, and CMM seams. |
| `schema-registry` | Avro compatibility and contract evidence. |
| `identity-service` | Authorization, effective permissions, service JWT validation, audit. |
| `reference-data-service` | Reference APIs, validation, outbox/event evidence. |
| `apps-auth` | Auth UI/app route. |
| `apps-reference-data` | Reference Data Enterprise Web route. |
| `nginx` | Reverse proxy for backend/frontend/callback routes. |
| `seed-loader` | Deterministic local seed application. |
| `contract-devtools` | Contract validation/dev tooling. |
| `prometheus`, `grafana`, `jaeger`, `otel-collector`, `elasticsearch`, `kibana` | Metrics, dashboards, traces, telemetry, and log/search stack. |

## Ports And Identities

| Item | Inventory |
|---|---|
| Ports | Postgres 5432, Keycloak 8080, Schema Registry 8081, Kafka 9092, Identity 8082, Reference Data 8083, nginx 8088, Grafana 3001. |
| Service identities | `linercore-identity-service`, `linercore-reference-data-service` with local Keycloak issuer and bounded capabilities. |
| Secrets/config | `infrastructure/env/local.env.example` is local-only and secret-safe; production secrets are not configured. |
| Databases | Local bootstrap defines service-owned logical DBs/users; most Java services still use in-memory adapters until persistent repositories are wired. |

## AWS Inventory

No VPCs, subnets, security groups, NACLs, Secrets Manager parameters, RDS clusters, ECS/EKS/Lambda services, ECR repositories, or S3 deployment buckets are defined in this repository for this intent.
