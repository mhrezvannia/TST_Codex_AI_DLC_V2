# Environment Provisioning Questions - LinerCore Enterprise

## Source Context

These questions consume unit `deployment-architecture`, unit `infrastructure-services`, and Operation `cd-config`. Local/CI environments are defined; AWS staging/production environments are not provisioned.

## Questions And Assumptions

| Question | Current answer | Required decision |
|---|---|---|
| Are all environments provisioned per infrastructure design? | Local and CI evidence only. | Choose AWS account/region and create staging/production IaC. |
| Are VPCs, subnets, security groups, and NACLs correct? | Not applicable yet. | Define network topology and validation checks. |
| Are secrets in Secrets Manager or Parameter Store? | No production secrets configured. | Define secret names, owners, rotation, and injection mechanism. |
| Is cross-account or cross-VPC connectivity validated? | Not applicable yet. | Define account/VPC model and connectivity controls. |
| Is Docker/full runtime available in CI? | Unknown. | Confirm whether self-hosted runner can run live Compose readiness. |
| Are compliance evidence retention controls provisioned? | Not yet. | Choose artifact/audit retention store and retention period. |

## Recommended Next Decisions

1. Select runtime platform for Java services and Enterprise Web hosting.
2. Select managed data/event services or self-managed container equivalents.
3. Define AWS account/region/VPC topology.
4. Define secret and parameter naming conventions.
5. Define evidence retention storage and access control.
6. Decide whether live readiness runs in CI or staging only.
