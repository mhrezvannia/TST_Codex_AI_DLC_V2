# Full ERP Flow Checkpoint

Last updated: 2026-07-10

Scope: finish the functional local ERP flow at code/test level while leaving Docker Desktop runtime troubleshooting aside.

## Current Checkpoint

- [x] Refresh Graphify code graph.
- [x] Confirm local Maven launcher is in place for `yarn backend:build` and `yarn backend:test`.
- [x] Add Booking Spring container module with REST API.
- [x] Add Container Movement Spring container module with REST API.
- [x] Add missing application-service operations needed by the API surface.
- [x] Add Booking UI app.
- [x] Add Container Movement UI app.
- [x] Wire frontend API clients to service endpoints.
- [x] Add service-to-service adapters for reference validation, charge pricing, booking-confirmed intake, and movement-status callbacks.
- [x] Add seeds and smoke helpers for the reference data -> charge agreement -> booking -> movement flow.
- [x] Add backend/API tests, contract checks, UI tests, and local smoke coverage.
- [x] Run `yarn install`, `yarn backend:build`, `yarn backend:test`, and relevant frontend tests.
- [ ] Run Docker-backed live full-flow smoke after Docker Desktop image pull/storage issue is resolved.

## Target Flow

1. Create reference data for customer, locations, equipment, commodity, currency, and charge codes.
2. Create and approve a charge agreement.
3. Create a booking using the reference records.
4. Validate and price the booking through Charge Agreement.
5. Confirm the booking.
6. Create or reconcile a container journey from the confirmed booking.
7. Capture departure, arrival, and delivery movement events.
8. Feed movement status back to Booking.
9. Verify persistence and idempotency through repositories and smoke tests.

## Restart Instruction

If work stops mid-task, resume from this file, run Graphify query/update as needed, then continue with the first unchecked item.

## Latest Verified Commands

- `yarn install`
- `yarn backend:build`
- `yarn backend:test`
- `yarn seed:validate`
- `yarn smoke:local`
- `yarn workspace @erp/ui typecheck`
- `yarn workspace @erp/app-booking typecheck`
- `yarn workspace @erp/app-container-movement typecheck`
- `yarn workspace @erp/app-booking test`
- `yarn workspace @erp/app-container-movement test`
- `node --test scripts/seed-local.test.mjs scripts/local-readiness.test.mjs scripts/runtime-devex.test.mjs`

Docker-backed runtime validation was intentionally not run in this checkpoint.
