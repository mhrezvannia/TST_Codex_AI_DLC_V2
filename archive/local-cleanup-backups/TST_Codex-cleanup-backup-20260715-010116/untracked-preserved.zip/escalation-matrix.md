# Escalation Matrix - LinerCore Enterprise

## Source Context

This escalation matrix consumes `dashboards`, `alarms`, `reliability-design`, `security-design`, and `deployment-architecture`. Named on-call rotations are not configured yet, so owners are role-based.

## Role Matrix

| Incident type | Primary owner | Secondary owner | Escalate when |
|---|---|---|---|
| Readiness failed/blocked | Operations | Local Runtime Platform | Promotion is blocked or blocker repeats. |
| Contract health red | Contract Platform | Owning provider/consumer service | Required contract seam fails. |
| Seed/runtime devex | Local Runtime Platform | Reference Data/Identity owners | Seed, DB owner, reset, or bootstrap validation fails. |
| Authorization/security | Identity/Security | Compliance | Denial spike, bypass risk, secret exposure, or audit gap. |
| Booking/Charge/CMM flow | Owning service | Integration owner | Pricing, D&D, booking confirmation, movement status flow fails. |
| Observability missing | Operations | Owning service | Required logs/metrics/traces/dashboard signal absent. |
| Cloud/provisioning | AWS Platform | DevSecOps | VPC/IAM/secrets/runtime provisioning fails. |

## Escalation Timing

- SEV1: immediate page and incident commander assignment.
- SEV2: owner assignment within 30 minutes during deployment window.
- SEV3: ticket owner by next business day.
- SEV4: backlog triage.

## Open Setup

Production launch requires named on-call rotation, notification channels, escalation contacts, and incident commander rota.
