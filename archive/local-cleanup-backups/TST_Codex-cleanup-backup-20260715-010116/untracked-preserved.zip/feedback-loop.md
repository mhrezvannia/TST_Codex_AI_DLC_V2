# Feedback Loop - LinerCore Enterprise

## Source Context

This feedback loop consumes `dashboards`, `alarms`, `slo-config`, `deployment-log`, `load-test-results`, and `incident-plan`.

## Inputs To Next Ideation Cycle

| Theme | Evidence | Proposed next work |
|---|---|---|
| Live runtime readiness | Local readiness blocked on Docker/service availability | Stand up full local or staging runtime and make live readiness green. |
| Persistence | Runtime devex notes Java services still use in-memory adapters unless dataaccess wiring exists | Add persistent repositories/migrations for service-owned data. |
| Deployment target | CD/environment provisioning show no staging/production target | Select runtime platform, registry, secrets, network, and IaC approach. |
| UI coverage | Enterprise Web improved Reference Data and Charge workflows; Booking/CMM UI routes still absent | Build Booking/CMM workflow surfaces and visual integration. |
| Observability | Assets exist but live telemetry not ingested | Wire service runtime metrics/logs/traces and dashboard live panels. |
| Performance | Load testing blocked by no live endpoints | Create k6 scripts after staging/live endpoints exist. |
| Security pipeline | Current checks cover auth/local secret/policy; SAST/DAST/dependency scanning not provisioned | Add CI security scanners and severity gates. |
| Operations | Incident/on-call roles are role-based only | Define named on-call, notification channels, RTO/RPO, backup/DR. |

## Improvement Backlog

1. Provision staging environment and artifact repositories.
2. Wire persistent dataaccess modules and migrations beyond Charge SQL.
3. Run full live readiness with Docker/services available.
4. Add Booking and CMM frontend workflows.
5. Add production-grade telemetry instrumentation.
6. Add SAST/DAST/dependency scanning.
7. Define backup, rollback, DR, and incident ownership.

## Feedback Decision

The workflow has enough evidence to close the current lifecycle as an enterprise construction/operation readiness package, but the next ideation cycle should focus on live deployment, persistence, and missing workflow surfaces.
