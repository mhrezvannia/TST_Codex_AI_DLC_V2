# Feedback Optimization Questions - LinerCore Enterprise

## Source Context

These questions consume `dashboards`, `alarms`, `slo-config`, `deployment-log`, `load-test-results`, and `incident-plan`.

## Questions And Answers

| Question | Current answer | Follow-up |
|---|---|---|
| Are SLOs being met? | Evidence SLOs are met locally; live SLOs not measured. | Run live telemetry after staging/prod exists. |
| What is error budget burn? | Not available without production traffic. | Define windows and collect live metrics. |
| Are there cost opportunities? | Avoid premature always-on cloud resources; keep observability optional locally. | Use Cost Explorer after AWS resources exist. |
| Is there drift? | No AWS drift; local/CI config mostly aligned, with runtime live blockers. | Add IaC and runtime metadata drift checks. |
| What user behavior suggests new features/issues? | No production user behavior data. | Instrument workflow analytics after deployment. |
| What toil can be automated? | Runtime readiness, evidence collection, artifact upload already automated; live provisioning and incident automation remain. | Add IaC, SSM/Incident Manager, live CI readiness. |

## Final Open Decisions

- Live deployment target and artifact repositories.
- Persistent data storage strategy.
- Booking/CMM frontend scope.
- Production telemetry and SLO thresholds.
- Security scanner tooling.
- Named operations ownership.
