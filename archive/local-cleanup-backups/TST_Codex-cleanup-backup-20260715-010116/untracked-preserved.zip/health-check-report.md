# Health Check Report - LinerCore Enterprise

## Source Context

This health report consumes `cd-config`, `deployment-strategy`, `environment-inventory`, and `build-test-results`. It distinguishes repository health, local runtime metadata health, and unavailable live service health.

## Health Checks

| Health area | Status | Evidence |
|---|---|---|
| Repository build/test health | Green | `build-test-results`: Maven reactor, frontend tests/typechecks, scripts, contracts, runtime devex, observability smoke passed. |
| Local runtime metadata | Green | Full runtime plan resolves services, ports, identities, and IDE modes. |
| Compose manifest smoke | Green | `smoke-local` passed. |
| Observability config | Green | `smoke-observability` passed. |
| Live service readiness | Blocked | Local readiness reports missing Docker/service ports in this session. |
| Cloud environment health | Not available | `environment-inventory` has no AWS staging/production resources. |

## Readiness Evidence

Latest readiness bundle: `artifacts\readiness\local-readiness.json`

Summary:

- Passed: 9
- Blocked: 3
- Failed: 0

Blocked owners:

- `local-runtime-platform`: prerequisites/Docker/service ports.
- `contract-platform`: live provider verification cannot reach services.
- `reference-data-service`: live seed apply cannot reach services.

## Health Decision

The repository and offline deployment evidence are healthy. Live runtime and cloud health cannot pass until the target environment is provisioned and running.
