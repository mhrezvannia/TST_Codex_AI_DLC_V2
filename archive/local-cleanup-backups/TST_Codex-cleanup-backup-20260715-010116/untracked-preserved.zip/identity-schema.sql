CREATE TABLE IF NOT EXISTS identity_role_assignments (
    assignment_id VARCHAR(64) PRIMARY KEY,
    subject_id VARCHAR(128) NOT NULL,
    role_id VARCHAR(128) NOT NULL,
    status VARCHAR(32) NOT NULL,
    assigned_at TIMESTAMP,
    version BIGINT NOT NULL,
    snapshot TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_identity_role_assignments_subject_status
    ON identity_role_assignments(subject_id, status);

CREATE UNIQUE INDEX IF NOT EXISTS idx_identity_role_assignments_subject_role
    ON identity_role_assignments(subject_id, role_id);

CREATE TABLE IF NOT EXISTS identity_authorization_audit (
    audit_id VARCHAR(64) PRIMARY KEY,
    event_type VARCHAR(64) NOT NULL,
    actor_subject_id VARCHAR(128),
    target_subject_id VARCHAR(128),
    resource VARCHAR(128),
    action VARCHAR(128),
    result VARCHAR(64),
    occurred_at TIMESTAMP,
    correlation_id VARCHAR(128),
    snapshot TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_identity_authorization_audit_subject
    ON identity_authorization_audit(actor_subject_id, occurred_at);
