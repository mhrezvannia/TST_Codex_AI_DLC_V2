# Incident Plan - LinerCore Enterprise

## Source Context

This incident plan consumes `dashboards`, `alarms`, `reliability-design`, `security-design`, and `deployment-architecture`. It supports local/CI evidence incidents now and can be mapped to AWS Incident Manager later.

## Severity Levels

| Severity | Definition | Response |
|---|---|---|
| SEV1 | Production customer-impacting outage or data/security incident. | Page on-call, incident commander, security/compliance as needed. |
| SEV2 | Staging/prod promotion blocked by failed required evidence or service outage. | Assign owner immediately; pause promotion. |
| SEV3 | CI/local readiness blocked but no release in progress. | Create ticket with owner/remediation. |
| SEV4 | Advisory anomaly or missing optional dashboard. | Backlog item. |

## Incident Lifecycle

1. Detect through alarm, quality gate, readiness evidence, or operator report.
2. Triage severity and owner.
3. Stabilize: rollback, pause deploy, disable risky feature, or restore dependency.
4. Communicate status and next update time.
5. Resolve or mitigate.
6. Capture evidence and timeline.
7. Run blameless review for SEV1/SEV2 and any repeated SEV3.

## Communication

- Incident commander owns timeline and status.
- Service owner owns technical diagnosis/remediation.
- Security/compliance joins any suspected auth, secret, data leakage, or audit issue.
- Product/customer comms owner must be named before production launch.

## Disaster Recovery Placeholder

RTO/RPO are not finalized. Until persistent stores and production topology are defined, DR is limited to repository rollback and regeneration of local/CI evidence.
