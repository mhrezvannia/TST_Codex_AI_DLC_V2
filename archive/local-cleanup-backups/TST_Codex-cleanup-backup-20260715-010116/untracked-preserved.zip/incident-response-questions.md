# Incident Response Questions - LinerCore Enterprise

## Source Context

These questions consume `dashboards`, `alarms`, `reliability-design`, `security-design`, and `deployment-architecture`.

## Questions And Answers

| Question | Current answer | Follow-up |
|---|---|---|
| What are the most likely failure modes? | Readiness blockers, contract failures, seed/API unavailability, outbox/event lag, auth denial anomalies, observability signal gaps. | Add production failure modes after runtime target selection. |
| What are escalation paths and on-call rotations? | Role-based only. | Define named on-call, notification channels, and incident commander rotation. |
| What automated remediation is possible? | Rerun validations and regenerate evidence; no production automation yet. | Add SSM Automation/Incident Manager once AWS environment exists. |
| What are communication procedures? | Incident commander/service owner split is defined. | Name product/customer comms owners before production. |
| What are RTO/RPO targets? | Not finalized. | Define after persistent stores and production topology are selected. |

## Blocking Decisions

- Named on-call and escalation channels.
- Incident Manager/SSM Automation target.
- Backup/restore ownership and RTO/RPO.
- Customer communication policy.
