# Integration Test Instructions - LinerCore Enterprise

## Source Context

These integration instructions consume the construction `code-generation-plan` and `code-summary` artifacts, with emphasis on cross-unit seams: Booking-to-Charge pricing, Booking confirmed to CMM, CMM movement status to Booking, Reference Data/Identity shared platform, local runtime, and observability readiness.

## Offline Integration Commands

| Seam | Command | Expected result |
|---|---|---|
| Contract catalog | `node scripts\validate-contract-catalog.mjs` | Catalog green with OpenAPI, AsyncAPI, Avro, Pact, and message-pact coverage. |
| Provider contracts | `node scripts\verify-contract-providers.mjs` | Offline provider shape checks pass and live checks are skipped. |
| Runtime devex | `node scripts\runtime-devex.mjs --seed-file infrastructure\seeds\shared-platform-mvp-defaults.json` | Logical DB owners, reset scopes, seed validity, bootstrap, and migration target checks pass. |
| Local readiness evidence | `node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json` | Offline checks pass; live-only checks may block when services are unavailable. |
| Observability smoke | `node scripts\smoke-observability.mjs` | Observability files, profiles, dashboard, and readiness signals are present. |

## Live Integration Commands

Run after Docker Desktop and the full local runtime are available:

```powershell
node scripts\local-runtime.mjs start --profile full
node scripts\verify-contract-providers.mjs --live --evidence-file artifacts\contracts-live-verification.json
node scripts\seed-local.mjs --seed-file infrastructure\seeds\shared-platform-mvp-defaults.json --summary-file artifacts\seed-apply-attempt.json
node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json
```

## Test Data

Use `infrastructure\seeds\shared-platform-mvp-defaults.json` for deterministic Reference Data and Identity role setup. Do not use production data or routable user email addresses in local/CI seeds.
