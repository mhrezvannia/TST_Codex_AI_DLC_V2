import type { ReactNode } from "react";
import { PlatformShell } from "@erp/ui";

export const metadata = {
  title: "LinerCore Booking",
  description: "Booking workbench"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <PlatformShell title="Booking">{children}</PlatformShell>
      </body>
    </html>
  );
}
