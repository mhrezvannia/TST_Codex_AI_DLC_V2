import type { ReactNode } from "react";
import { PlatformShell } from "@erp/ui";

export const metadata = {
  title: "LinerCore Container Movement",
  description: "Container movement management workbench"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <PlatformShell title="Container Movement">{children}</PlatformShell>
      </body>
    </html>
  );
}
