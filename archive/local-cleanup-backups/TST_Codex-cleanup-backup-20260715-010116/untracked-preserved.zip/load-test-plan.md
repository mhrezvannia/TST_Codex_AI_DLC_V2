# Load Test Plan - LinerCore Enterprise

## Source Context

This plan consumes `performance-requirements`, `scalability-requirements`, `performance-design`, `scalability-design`, and `dashboards`. No production-like live environment exists yet, so load execution is planned but not run.

## Planned Scenarios

| Scenario | Target flow | Tool candidate |
|---|---|---|
| Reference Data reads/mutations | Enterprise Web/API to Reference Data and outbox publication | k6 or Artillery |
| Booking create/confirm | Booking lifecycle, pricing handoff, confirmation event | k6 |
| Booking to Charge pricing/D&D | Pricing quote and D&D request/response | k6 |
| Booking confirmed to CMM | Event publication and journey reconciliation freshness | k6 plus event lag probes |
| CMM status to Booking | Status event publication/consumption and D&D trigger evidence | k6 plus event lag probes |
| Readiness evidence | Local/CI evidence bundle generation and quality gate evaluation | Node timing harness |

## Test Types

- Ramp-up test for expected traffic.
- Steady-state test for sustained load.
- Spike test for queue/outbox/backpressure behavior.
- Soak test after persistent repositories and live services are available.

## Preconditions

- Staging environment provisioned.
- Live services running with HTTP endpoints.
- Persistent repositories wired where required.
- Observability dashboards and metrics ingesting live data.
- Deterministic seed applied successfully.
