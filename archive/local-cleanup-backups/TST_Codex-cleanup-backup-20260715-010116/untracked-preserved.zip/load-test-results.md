# Load Test Results - LinerCore Enterprise

## Source Context

These results consume `performance-requirements`, `scalability-requirements`, `performance-design`, `scalability-design`, and `dashboards`.

## Executed Results

| Check | Result |
|---|---|
| Maven reactor regression | Passed in 56.606 seconds during build-and-test. |
| Script test regression | Passed 48 tests in about 2 seconds during build-and-test reruns. |
| Local readiness evidence generation | Completed in about 34 seconds with `status: blocked`, 9 passed, 3 blocked, 0 failed. |
| Observability smoke | Passed in under 1 second. |
| Runtime plan resolution | Passed in under 1 second. |

## Blocked Load Tests

Full load tests were not executed because `environment-inventory` and deployment execution show no staging/production environment and no live service endpoints. Local readiness also shows Docker/live service blockers.

## Bottleneck Hypotheses

- Service-owned persistence is mostly in-memory now; production database behavior is unknown.
- Event/outbox freshness and Schema Registry compatibility require live Kafka/registry checks.
- Enterprise Web dashboard performance needs real browser/runtime measurement after deployment.
- Evidence bundle time is acceptable locally, but CI runtime should be monitored after workflow execution.
