# Log Queries - LinerCore Enterprise

## Source Context

These log query definitions consume `performance-design`, `security-design`, `reliability-design`, `monitoring-design`, and `infrastructure-services`. Local logs should follow the safe telemetry rules in `infrastructure/observability/README.md`.

## Required Fields

Structured JSON logs must include:

- timestamp
- level
- service or app
- environment
- operation
- correlation id
- result
- safe error code

Logs must not include tokens, passwords, credentials, cookies, secret claims, restricted payloads, or production identifiers.

## Query Catalog

| Query | Purpose |
|---|---|
| `correlation_id = <id>` | Trace a request across HTTP, service, event, and readiness logs. |
| `level in (ERROR,WARN) by service` | Find current service errors and warning clusters. |
| `operation = authorization_decision and result = denied` | Review denied-path evidence and suspicious access attempts. |
| `operation = outbox_publish and result != success` | Diagnose publication failures and retry loops. |
| `operation = readiness_check and status in (failed,blocked)` | Find release blockers by owner/source. |
| `safe_error_code exists and service = <service>` | Group recurring application failures without leaking internals. |

## Retention

Local log retention is Compose-volume scoped. Production retention, indexing, and archive policy must be defined when the monitoring backend is selected.
