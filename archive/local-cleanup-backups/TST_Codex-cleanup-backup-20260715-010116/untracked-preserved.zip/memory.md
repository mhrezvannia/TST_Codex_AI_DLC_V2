# Build And Test Memory

## Interpretations

- 2026-07-10T04:02:25Z - Treated the active Comprehensive test strategy as requiring backend, frontend, contract, runtime evidence, observability, and security checks; generated all instruction artifacts instead of only unit/integration instructions.
- 2026-07-10T04:02:25Z - Treated local readiness `blocked` as an expected fail-closed runtime state when Docker/live services are unavailable; offline build/test readiness still passes.

## Deviations

- 2026-07-10T04:02:25Z - Used the root Vitest binary for Reference Data and Auth tests because workspace test wrappers are inconsistent; this matches prior successful verification commands.

## Tradeoffs

- 2026-07-10T04:02:25Z - Added a direct TypeScript dev dependency to `@erp/ui` instead of relying on hoisted/root tooling; this makes the workspace typecheck command self-contained.

## Open questions

- 2026-07-10T04:02:25Z - Confirm in Operation whether live Compose runtime, persistent repositories, backup/rollback/DR, and production-grade SAST/DAST/dependency scanners are required before the next release gate.
