# CI Pipeline Memory

## Interpretations

- 2026-07-10T04:05:34Z - Treated GitHub Actions as the active CI tool because `.github/workflows/quality-gates.yml` already exists and aligns with build-and-test outputs.

## Deviations

- 2026-07-10T04:05:34Z - Did not add deployable artifact publishing in Construction CI; no artifact repository target has been defined, so publishing belongs to Operation deployment pipeline design.

## Tradeoffs

- 2026-07-10T04:05:34Z - Kept live runtime readiness as uploaded blocked evidence instead of a mandatory PR blocker; this avoids failing every PR on runners without Docker/services while preserving the operational gap.

## Open questions

- 2026-07-10T04:05:34Z - Confirm whether CI should provision Docker Compose services for live provider verification before Operation, or keep live checks as Operation-stage gates.
