# NFR Validation Matrix - LinerCore Enterprise

## Source Context

This matrix consumes `performance-requirements`, `scalability-requirements`, `performance-design`, `scalability-design`, and `dashboards`.

## Matrix

| NFR | Target | Actual | Status | Evidence |
|---|---|---|---|---|
| Quality gate evaluation | <= 2 minutes after collection | Not separately timed; script tests fast, local readiness 34s | Partial | Build/test and readiness runs. |
| Contract aggregation | <= 60 seconds after checks | Contract scripts completed quickly in local runs | Pass | Contract catalog/provider verification. |
| Full CI evidence bundle | <= 15 minutes | Local executed checks are under target; CI run not observed | Partial | Build-test local timings. |
| Full local evidence bundle | <= 20 minutes after runtime ready | 34s with live blockers and no runtime services | Partial | `artifacts/readiness/local-readiness.json`. |
| Operations dashboard load | p95 <= 2 seconds | Not measurable without live UI/observability backend | Blocked | Dashboards configured, live data unavailable. |
| Event freshness/outbox lag | Threshold pending | Not measurable without live Kafka/outbox | Blocked | Observability signals defined. |
| API latency/throughput | Threshold pending | Not measurable without live endpoints | Blocked | Load-test plan only. |

## Decision

Performance validation is complete for available local command/runtime evidence. Production-like performance validation is blocked until staging/live services, persistent stores, telemetry ingestion, and traffic targets exist.
