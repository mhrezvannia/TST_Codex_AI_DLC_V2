# Observability Setup Questions - LinerCore Enterprise

## Source Context

These questions consume `performance-design`, `security-design`, `reliability-design`, `monitoring-design`, and `infrastructure-services`.

## Questions And Answers

| Question | Current answer | Follow-up |
|---|---|---|
| What golden signals are tracked? | Latency, traffic, errors, saturation, event freshness, outbox lag, readiness status, authorization decisions. | Confirm production thresholds. |
| What SLOs/SLIs are defined? | Initial SLIs/SLOs are defined for quality gates, contracts, readiness, dashboard load, and service/event health. | Add measured production targets after staging/prod telemetry exists. |
| What dashboard layouts are needed? | Shared Platform overview plus contract/readiness/runtime panels. | Add service-specific dashboards after live endpoints exist. |
| What log retention and aggregation rules apply? | Local-only rules exist; production retention is not configured. | Choose monitoring/log backend retention and archive policy. |
| What tracing instrumentation is needed? | HTTP, event, outbox, and integration spans with correlation propagation. | Wire service runtime tracing. |

## Blocking Decisions

- Production monitoring backend and alert routing.
- On-call/incident ownership.
- Service runtime instrumentation path.
- Production log retention and audit storage.
- SLO thresholds based on measured baseline.
