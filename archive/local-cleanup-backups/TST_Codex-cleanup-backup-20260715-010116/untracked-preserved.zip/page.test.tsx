import { render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { ContainerMovementWorkbench } from "./ContainerMovementWorkbench";
import { fallbackJourneys } from "../lib/container-movement";

describe("ContainerMovementWorkbench", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("renders journey intake and movement capture controls", () => {
    vi.stubGlobal("fetch", () => new Promise(() => undefined));

    render(<ContainerMovementWorkbench initialJourneys={fallbackJourneys} />);

    expect(screen.getByText("Container Movement")).toBeTruthy();
    expect(screen.getByText("Booking-confirmed intake")).toBeTruthy();
    expect(screen.getByText("Create journey")).toBeTruthy();
    expect(screen.getByText("Capture movement")).toBeTruthy();
  });
});
