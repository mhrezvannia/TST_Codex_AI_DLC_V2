import { render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { BookingWorkbench } from "./BookingWorkbench";
import { fallbackBookings } from "../lib/bookings";

describe("BookingWorkbench", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("renders the booking workflow controls", () => {
    vi.stubGlobal("fetch", () => new Promise(() => undefined));

    render(<BookingWorkbench initialBookings={fallbackBookings} />);

    expect(screen.getByText("Booking Workbench")).toBeTruthy();
    expect(screen.getByText("Create booking")).toBeTruthy();
    expect(screen.getByText("Validate")).toBeTruthy();
    expect(screen.getByText("Price")).toBeTruthy();
    expect(screen.getByText("Confirm")).toBeTruthy();
  });
});
