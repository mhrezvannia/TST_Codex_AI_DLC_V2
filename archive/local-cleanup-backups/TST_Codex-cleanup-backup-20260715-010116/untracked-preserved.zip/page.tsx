import { BookingWorkbench } from "./BookingWorkbench";
import { fallbackBookings } from "../lib/bookings";

export default function BookingHomePage() {
  return <BookingWorkbench initialBookings={fallbackBookings} />;
}
