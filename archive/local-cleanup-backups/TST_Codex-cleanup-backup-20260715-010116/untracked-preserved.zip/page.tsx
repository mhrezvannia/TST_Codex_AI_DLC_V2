import { ContainerMovementWorkbench } from "./ContainerMovementWorkbench";
import { fallbackJourneys } from "../lib/container-movement";

export default function ContainerMovementHomePage() {
  return <ContainerMovementWorkbench initialJourneys={fallbackJourneys} />;
}
