# Performance Test Instructions - LinerCore Enterprise

## Source Context

These instructions consume the NFR-driven `code-generation-plan` and `code-summary` outputs, especially local runtime, observability/readiness, Enterprise Web workflow surfaces, and service integration seams. The current implementation provides performance readiness hooks and smoke evidence, not a production load-test environment.

## Baseline Commands

| Check | Command | Purpose |
|---|---|---|
| Backend regression time | `.\.local-tools\apache-maven\bin\mvn.cmd -f services\pom.xml test` | Keep Java domain/application tests under CI-friendly runtime. |
| Script regression time | `node --test scripts\*.test.mjs` | Keep local evidence/contract scripts fast enough for every PR. |
| Readiness evidence budget | `node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json` | Validate bounded evidence collection and clear blocker reporting. |
| Observability profile | `node scripts\smoke-observability.mjs` | Confirm metric/log/trace/dashboard assets exist before load testing. |

## Future Load Tests

- Add k6 or Artillery scripts once HTTP container endpoints for Booking, Charge, CMM, Identity, and Reference Data are wired.
- Validate p95 dashboard load below 2 seconds and quality gate evaluation below 2 minutes after evidence collection.
- Track RED metrics for APIs and event freshness/outbox lag metrics for Kafka seams.
- Compare every run against an NFR target-vs-actual matrix before Operation promotion.
