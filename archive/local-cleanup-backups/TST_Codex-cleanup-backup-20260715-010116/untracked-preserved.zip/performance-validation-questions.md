# Performance Validation Questions - LinerCore Enterprise

## Source Context

These questions consume `performance-requirements`, `scalability-requirements`, `performance-design`, `scalability-design`, and `dashboards`.

## Questions And Answers

| Question | Current answer | Follow-up |
|---|---|---|
| What are expected traffic patterns? | Not defined. | Define steady, peak, burst, and seasonal traffic for core flows. |
| What are target latency percentiles? | Evidence/dashboard targets exist; service/API targets pending. | Define p50/p95/p99 per route/flow. |
| What throughput must the system sustain? | Not defined. | Define requests/sec and events/sec targets. |
| Where are likely bottlenecks? | Persistence, event/outbox, UI dashboards, evidence bundle CI time. | Validate after live environment exists. |
| What tool should be used? | k6 preferred for HTTP/API flows. | Add scripts after live endpoints exist. |

## Blocking Decisions

- Staging/live endpoint availability.
- Persistent repository wiring.
- Traffic model and thresholds.
- Observability backend with live telemetry.
- Synthetic test data volume.
