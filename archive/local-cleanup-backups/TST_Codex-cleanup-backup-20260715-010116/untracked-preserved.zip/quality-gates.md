# Quality Gates - LinerCore Enterprise

## Source Context

These quality gates consume every construction `code-summary`, plus `build-and-test-summary` and `build-test-results`. They map the passing local build/test evidence into CI-enforced checks.

## Required Gates

| Gate | Command | Blocks merge when |
|---|---|---|
| Package manager policy | `policy-package-manager` inside `scripts/run-quality-gates.mjs` | A non-Yarn lockfile appears or `packageManager` is not Yarn. |
| Backend domain purity | `backend-domain-purity` | Domain-core modules depend on Spring/JPA/Kafka/Jackson/Lombok/dataaccess/messaging. |
| Contract catalog | `node scripts/validate-contract-catalog.mjs` | Required OpenAPI, AsyncAPI, Avro, Pact, or message-pact evidence is missing/stale/invalid. |
| Provider contracts | `node scripts/verify-contract-providers.mjs` | Offline provider shape checks fail. |
| Runtime devex | `node scripts/runtime-devex.mjs --seed-file infrastructure/seeds/shared-platform-mvp-defaults.json` | DB owners, bootstrap, reset scopes, migration target, local-only data, or seed validity fails. |
| Local readiness evidence | `node scripts/local-readiness.mjs --profile full --evidence artifacts/readiness/local-readiness.json` | Offline checks fail; live-only unavailable services are preserved as blocked evidence. |
| Observability smoke | `node scripts/smoke-observability.mjs` | Required observability files/signals/dashboard profile are missing. |
| Seed validation | `node scripts/seed-local.mjs --dry-run --seed-file infrastructure/seeds/shared-platform-mvp-defaults.json` | Seed pack validity or local data safety fails. |
| Frontend Reference Data | Vitest and typecheck gates in `run-quality-gates.mjs` | UI tests or TypeScript checks fail. |
| Frontend Auth | Typecheck gate plus Auth Vitest commands from build/test results | Auth type safety or behavior checks fail. |
| Frontend Charge Agreements | Workspace test/typecheck gates | Workbench rendering or TypeScript checks fail. |
| Backend tests | `mvn -f services/pom.xml test` | Any Java reactor module fails. |

## Evidence Expectations

- Every required gate must write a pass/fail/blocked status into CI output or uploaded artifacts.
- Readiness evidence must include owner, category, command, freshness key, blocker reason, and remediation.
- Manual notes cannot make failed, missing, stale, or blocked machine evidence green.
- Live runtime checks are allowed to report `blocked` on a CI runner without full services, but they must not be hidden.

## Promotion Criteria

Construction can move forward when:

- Required offline gates pass.
- Local readiness evidence has no `failed` checks.
- Blocked live-runtime checks are explicitly carried to Operation with owner and remediation.
- Security-sensitive checks for auth, local-only secrets, domain purity, and evidence redaction pass.
