# Rollback Runbook - LinerCore Enterprise

## Source Context

This rollback runbook consumes `ci-config`, `quality-gates`, unit `deployment-architecture`, and unit `cicd-pipeline` artifacts. Current deployment artifacts are repository changes and evidence outputs; production runtime deployment is not configured yet.

## Rollback Triggers

Rollback or halt promotion when any of these occur:

- CI quality gates fail.
- Live provider verification fails for a required contract.
- Seed apply fails for deterministic local/staging setup.
- Local/readiness evidence reports `failed` checks.
- Observability smoke fails or required metrics/logs/traces are absent.
- Error rate, latency, authorization-denial anomalies, or outbox lag exceed agreed thresholds after deployment.

## Repository Rollback

For Construction-stage repository changes:

1. Identify the last passing commit and evidence bundle.
2. Revert the offending commit(s) with normal Git revert, preserving audit history.
3. Rerun CI quality gates.
4. Regenerate `artifacts/readiness/local-readiness.json`.
5. Confirm contract health remains green and no schema compatibility rules were violated.

## Runtime Rollback

Once deployable runtime artifacts exist:

1. Stop traffic shift or pause rollout.
2. Repoint traffic to the previous healthy artifact/environment.
3. Keep new artifacts available for diagnosis; do not delete evidence.
4. Run post-rollback smoke checks and live provider verification.
5. Record incident owner, root-cause hypothesis, customer impact, and follow-up tasks.

## Database And Event Rollback

- Prefer forward-fix and expand-contract migrations.
- Do not drop/rename fields in the same release that introduces readers/writers.
- Event schema rollback must preserve Avro/AsyncAPI compatibility.
- If a bad event is published, remediate with compensating events or replay controls owned by the service, not cross-service database edits.

## Evidence To Capture

- Commit SHA and artifact identifiers.
- Failed gate/log path.
- Readiness evidence bundle.
- Contract health snapshot.
- Seed apply summary.
- Observability screenshots or exported dashboard/query links when available.
- Human approval and rollback decision timestamp.
