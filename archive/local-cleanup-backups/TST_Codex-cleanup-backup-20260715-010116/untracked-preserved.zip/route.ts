import { correlationId, proxyJson } from "../../../../../lib/container-movement";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return proxyJson(`/api/container-movement/journeys/${encodeURIComponent(id)}/movements`, { method: "POST", body: await request.text() }, correlationId(request));
}
