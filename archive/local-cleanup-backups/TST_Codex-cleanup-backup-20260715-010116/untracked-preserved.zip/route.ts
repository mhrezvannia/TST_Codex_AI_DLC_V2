import { correlationId, proxyJson } from "../../../../../lib/bookings";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return proxyJson(`/api/bookings/${encodeURIComponent(id)}/confirm`, { method: "POST", body: await request.text() }, correlationId(request));
}
