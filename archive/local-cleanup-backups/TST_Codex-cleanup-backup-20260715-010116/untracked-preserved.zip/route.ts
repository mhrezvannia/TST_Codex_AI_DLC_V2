import { correlationId, proxyJson } from "../../../lib/bookings";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const query = url.search || "?limit=25";
  return proxyJson(`/api/bookings${query}`, { method: "GET" }, correlationId(request));
}

export async function POST(request: Request) {
  return proxyJson("/api/bookings", { method: "POST", body: await request.text() }, correlationId(request));
}
