import { correlationId, proxyJson } from "../../../../lib/bookings";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return proxyJson(`/api/bookings/${encodeURIComponent(id)}`, { method: "GET" }, correlationId(request));
}
