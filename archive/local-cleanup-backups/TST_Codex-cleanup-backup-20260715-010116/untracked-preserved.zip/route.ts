import { correlationId, proxyJson } from "../../../../lib/container-movement";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return proxyJson(`/api/container-movement/journeys/${encodeURIComponent(id)}`, { method: "GET" }, correlationId(request));
}
