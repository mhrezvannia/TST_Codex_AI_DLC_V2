import { correlationId, proxyJson } from "../../../lib/container-movement";

export async function POST(request: Request) {
  return proxyJson("/api/container-movement/booking-confirmed", { method: "POST", body: await request.text() }, correlationId(request));
}
