import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";

const isWindows = process.platform === "win32";
const localMaven = resolve(".local-tools", "apache-maven", "bin", isWindows ? "mvn.cmd" : "mvn");
const localJdk = resolve(".local-tools", "jdk-21");
const command = process.env.MAVEN_CMD || (existsSync(localMaven) ? localMaven : "mvn");
const env = { ...process.env };

if (!env.JAVA_HOME && existsSync(localJdk)) {
  env.JAVA_HOME = localJdk;
  env.Path = `${resolve(localJdk, "bin")};${env.Path ?? env.PATH ?? ""}`;
  env.PATH = env.Path;
}

const result = spawnSync(command, process.argv.slice(2), {
  stdio: "inherit",
  shell: isWindows,
  env
});

if (result.error) {
  console.error(result.error.message);
  process.exit(1);
}

process.exit(result.status ?? 1);
