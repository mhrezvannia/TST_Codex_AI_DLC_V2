# Runbooks - LinerCore Enterprise

## Source Context

These runbooks consume `dashboards`, `alarms`, `reliability-design`, `security-design`, and `deployment-architecture`. They are markdown runbooks until SSM Automation/AWS Incident Manager targets are provisioned.

## Runbook Library

| Runbook | Trigger | First actions |
|---|---|---|
| Readiness failed | Readiness failed alarm | Open `artifacts/readiness/local-readiness.json`, identify failed evidence item, assign owner/remediation. |
| Live readiness blocked | Live blocker before staging/prod promotion | Start/provision dependent services, rerun live contracts/seed/readiness, record blocker owner. |
| Contract health red | Contract health red alarm | Run `node scripts\validate-contract-catalog.mjs` and `node scripts\verify-contract-providers.mjs`; inspect failed seam. |
| Seed apply failed | Seed apply blocker | Review `artifacts/seed-apply-attempt.json`; verify Identity/Reference Data APIs and seed pack fingerprint. |
| Outbox lag high | Outbox lag anomaly | Check owning service outbox publisher, Kafka/Schema Registry availability, and retry/dead-letter state. |
| Authorization anomaly | Denial spike | Review auth audit evidence, capability mappings, service identity, and suspicious subject/action patterns. |
| Observability missing | Trace/log/metric signal absent | Run `node scripts\smoke-observability.mjs`, inspect OTel/Prometheus/Grafana config, verify correlation header propagation. |

## Common Command Set

```powershell
node scripts\validate-contract-catalog.mjs
node scripts\verify-contract-providers.mjs
node scripts\runtime-devex.mjs --seed-file infrastructure\seeds\shared-platform-mvp-defaults.json
node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json
node scripts\smoke-observability.mjs
```

## Evidence Requirements

Every incident runbook execution must record alarm, owner, severity, correlation id or evidence run id, command output path, decision, remediation, and follow-up.
