import { createHash } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { loadSeedPack, orderedReferenceRecords, validateSeedPack } from "./seed-local.mjs";

export const DATABASE_OWNERS = [
  { service: "identity-service", database: "linercore_identity", owner: "linercore_identity" },
  { service: "reference-data-service", database: "linercore_reference_data", owner: "linercore_reference_data" },
  { service: "charge-agreement-service", database: "linercore_pricing", owner: "linercore_pricing" },
  { service: "booking-service", database: "linercore_booking", owner: "linercore_booking" },
  { service: "container-movement-service", database: "linercore_container_movement", owner: "linercore_container_movement" },
  { service: "keycloak", database: "linercore_keycloak", owner: "linercore_keycloak" },
  { service: "runtime-tools", database: "linercore_tools", owner: "linercore_tools" }
];

export const RESET_SCOPES = {
  referenceData: ["linercore_reference_data"],
  pricing: ["linercore_pricing"],
  booking: ["linercore_booking"],
  containerMovement: ["linercore_container_movement"],
  platform: ["linercore_identity", "linercore_reference_data", "linercore_tools"],
  full: DATABASE_OWNERS.map((owner) => owner.database)
};

export const MIGRATION_TARGETS = [
  {
    service: "identity-service",
    path: "services/identity-service/dataaccess/src/main/resources/db/identity-schema.sql"
  },
  {
    service: "reference-data-service",
    path: "services/reference-data-service/dataaccess/src/main/resources/db/reference-data-schema.sql"
  },
  {
    service: "charge-agreement-service",
    path: "services/charge-agreement-service/dataaccess/src/main/resources/db/charge-agreement-schema.sql"
  },
  {
    service: "booking-service",
    path: "services/booking-service/dataaccess/src/main/resources/db/booking-schema.sql"
  },
  {
    service: "container-movement-service",
    path: "services/container-movement-service/dataaccess/src/main/resources/db/container-movement-schema.sql"
  }
];

export function buildRuntimeDevexReport(options = {}) {
  const seedFile = options.seedFile ?? "infrastructure/seeds/shared-platform-mvp-defaults.json";
  const bootstrapPath = options.bootstrapPath ?? "infrastructure/database/00-local-bootstrap.sh";
  const envPath = options.envPath ?? "infrastructure/env/local.env.example";
  const pack = loadSeedPack(seedFile);
  const seedValidation = validateSeedPack(pack);
  const ownerValidation = validateDatabaseOwners(DATABASE_OWNERS);
  const migrationValidation = validateMigrationTargets(MIGRATION_TARGETS);
  const resetValidation = validateResetScopes(RESET_SCOPES, DATABASE_OWNERS);
  const secretValidation = validateLocalOnlyFiles([seedFile, envPath, bootstrapPath]);
  const bootstrapValidation = validateBootstrapScript(bootstrapPath, DATABASE_OWNERS);
  const status = [
    ownerValidation,
    migrationValidation,
    resetValidation,
    secretValidation,
    bootstrapValidation,
    { valid: seedValidation.valid, errors: seedValidation.errors }
  ].every((item) => item.valid) ? "ok" : "failed";

  return {
    status,
    generatedAt: new Date().toISOString(),
    databaseOwners: DATABASE_OWNERS,
    bootstrap: {
      path: bootstrapPath,
      valid: bootstrapValidation.valid,
      errors: bootstrapValidation.errors
    },
    migrations: {
      targets: migrationValidation.targets,
      errors: migrationValidation.errors
    },
    seed: {
      seedPackId: pack.seedPackId,
      seedVersion: pack.seedVersion,
      recordCount: orderedReferenceRecords(pack).length,
      fingerprint: fingerprintSeedPack(pack),
      valid: seedValidation.valid,
      errors: seedValidation.errors
    },
    resetScopes: RESET_SCOPES,
    validations: {
      owners: ownerValidation,
      migrations: { valid: migrationValidation.valid, errors: migrationValidation.errors },
      resetScopes: resetValidation,
      localOnlyData: secretValidation
    },
    persistenceNote: "Local bootstrap provisions logical databases/users. Identity, reference data, and charge agreement containers initialize JDBC schemas in local profile; booking and container movement have durable adapters ready for future container wiring."
  };
}

export function validateDatabaseOwners(owners) {
  const errors = [];
  const databaseNames = new Set();
  const ownerNames = new Set();
  for (const owner of owners) {
    for (const field of ["service", "database", "owner"]) {
      if (!owner[field] || typeof owner[field] !== "string") {
        errors.push(`database owner missing ${field}`);
      }
    }
    if (databaseNames.has(owner.database)) {
      errors.push(`duplicate database ${owner.database}`);
    }
    if (ownerNames.has(owner.owner)) {
      errors.push(`duplicate owner ${owner.owner}`);
    }
    databaseNames.add(owner.database);
    ownerNames.add(owner.owner);
  }
  return { valid: errors.length === 0, errors };
}

export function validateMigrationTargets(targets) {
  const errors = [];
  const enriched = targets.map((target) => {
    const exists = existsSync(resolve(target.path));
    if (!exists) {
      errors.push(`missing migration target ${target.service}: ${target.path}`);
    }
    return { ...target, exists };
  });
  return { valid: errors.length === 0, errors, targets: enriched };
}

export function validateResetScopes(scopes, owners) {
  const errors = [];
  const knownDatabases = new Set(owners.map((owner) => owner.database));
  for (const [scope, databases] of Object.entries(scopes)) {
    if (!Array.isArray(databases) || databases.length === 0) {
      errors.push(`reset scope ${scope} must name at least one database`);
    }
    for (const database of databases) {
      if (!knownDatabases.has(database)) {
        errors.push(`reset scope ${scope} references unknown database ${database}`);
      }
    }
  }
  return { valid: errors.length === 0, errors };
}

export function validateBootstrapScript(path, owners) {
  const absolutePath = resolve(path);
  const errors = [];
  if (!existsSync(absolutePath)) {
    return { valid: false, errors: [`missing bootstrap script ${path}`] };
  }
  const text = readFileSync(absolutePath, "utf8");
  for (const owner of owners) {
    if (!text.includes(owner.database) || !text.includes(owner.owner)) {
      errors.push(`bootstrap script missing ${owner.service} owner ${owner.database}/${owner.owner}`);
    }
  }
  return { valid: errors.length === 0, errors };
}

export function validateLocalOnlyFiles(paths) {
  const errors = [];
  const forbidden = [
    /postgres:\/\/[^/\s]+@[^/\s]*prod[^/\s]*/i,
    /https?:\/\/[^/\s]*prod[^/\s]*/i,
    /AKIA[0-9A-Z]{16}/,
    /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/
  ];
  for (const path of paths) {
    const absolutePath = resolve(path);
    if (!existsSync(absolutePath)) {
      errors.push(`missing local-only file ${path}`);
      continue;
    }
    const text = readFileSync(absolutePath, "utf8");
    for (const pattern of forbidden) {
      if (pattern.test(text)) {
        errors.push(`${path} contains forbidden pattern ${pattern}`);
      }
    }
    if (path.endsWith(".json")) {
      const emails = [...text.matchAll(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)].map((match) => match[0]);
      for (const email of emails) {
        if (!email.endsWith(".invalid")) {
          errors.push(`${path} contains routable email ${email}`);
        }
      }
    }
  }
  return { valid: errors.length === 0, errors };
}

export function fingerprintSeedPack(pack) {
  return createHash("sha256").update(JSON.stringify(pack)).digest("hex");
}

function parseArgs(argv) {
  const args = {
    seedFile: "infrastructure/seeds/shared-platform-mvp-defaults.json",
    evidenceFile: null
  };
  for (let index = 0; index < argv.length; index++) {
    if (argv[index] === "--seed-file") {
      args.seedFile = argv[++index];
    } else if (argv[index] === "--evidence-file") {
      args.evidenceFile = argv[++index];
    }
  }
  return args;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const args = parseArgs(process.argv.slice(2));
  const report = buildRuntimeDevexReport({ seedFile: args.seedFile });
  if (args.evidenceFile) {
    writeFileSync(resolve(args.evidenceFile), `${JSON.stringify(report, null, 2)}\n`);
  }
  console.log(JSON.stringify(report, null, 2));
  if (report.status !== "ok") {
    process.exit(1);
  }
}
