import test from "node:test";
import assert from "node:assert/strict";
import {
  DATABASE_OWNERS,
  RESET_SCOPES,
  buildRuntimeDevexReport,
  validateBootstrapScript,
  validateDatabaseOwners,
  validateMigrationTargets,
  validateResetScopes
} from "./runtime-devex.mjs";

test("runtime devex report validates local owners, migrations, seed, reset scopes, and bootstrap", () => {
  const report = buildRuntimeDevexReport();

  assert.equal(report.status, "ok", JSON.stringify(report.validations, null, 2));
  assert.equal(report.databaseOwners.length, 7);
  assert.equal(report.seed.valid, true);
  assert.equal(report.migrations.targets.every((target) => target.exists), true);
  assert.match(report.persistenceNote, /initialize JDBC schemas/);
});

test("database owners require unique logical databases and users", () => {
  const owners = [...DATABASE_OWNERS, { service: "duplicate", database: "linercore_booking", owner: "linercore_booking" }];

  const result = validateDatabaseOwners(owners);

  assert.equal(result.valid, false);
  assert.match(result.errors.join("\n"), /duplicate database/);
  assert.match(result.errors.join("\n"), /duplicate owner/);
});

test("reset scopes cannot reference unknown databases", () => {
  const result = validateResetScopes({ broken: ["outside_workspace"] }, DATABASE_OWNERS);

  assert.equal(result.valid, false);
  assert.match(result.errors.join("\n"), /unknown database/);
});

test("migration targets must exist", () => {
  const result = validateMigrationTargets([{ service: "missing", path: "services/missing/db/schema.sql" }]);

  assert.equal(result.valid, false);
  assert.match(result.errors.join("\n"), /missing migration target/);
});

test("bootstrap script covers every required owner", () => {
  const result = validateBootstrapScript("infrastructure/database/00-local-bootstrap.sh", DATABASE_OWNERS);

  assert.equal(result.valid, true, result.errors.join("\n"));
});

test("full reset scope covers every database owner exactly once", () => {
  assert.deepEqual([...RESET_SCOPES.full].sort(), DATABASE_OWNERS.map((owner) => owner.database).sort());
});
