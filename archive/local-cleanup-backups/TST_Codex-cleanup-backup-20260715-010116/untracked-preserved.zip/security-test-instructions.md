# Security Test Instructions - LinerCore Enterprise

## Source Context

These instructions consume the security-related `code-generation-plan` and `code-summary` outputs for shared identity, service authorization, local runtime, Enterprise Web, readiness evidence, and contract boundaries.

## Security Commands

| Check | Command | Purpose |
|---|---|---|
| Auth unit tests | `node .\node_modules\vitest\vitest.mjs --root . run packages\auth\src\index.test.ts apps\auth\lib\auth-server.test.ts --config vitest.config.ts` | Validate auth helpers and server decisions. |
| Backend authorization tests | `.\.local-tools\apache-maven\bin\mvn.cmd -f services\pom.xml test` | Exercise denied-path and capability checks in Identity, Booking, Charge, Reference Data, and CMM. |
| Policy checks | `node --test scripts\run-quality-gates.test.mjs` | Verify package-manager policy and domain-core impurity scanning. |
| Seed/runtime secret safety | `node scripts\runtime-devex.mjs --seed-file infrastructure\seeds\shared-platform-mvp-defaults.json` | Check local-only files for forbidden production URLs, credentials, private keys, and routable seed emails. |
| Evidence redaction | `node --test scripts\local-readiness.test.mjs` | Verify readiness summaries redact tokens, passwords, secrets, and authorization headers. |

## Promotion Gates

- Block promotion on failed denied-path tests, secret-like local artifacts, domain-core infrastructure dependencies, or missing service-to-service identity metadata.
- Run dependency/SAST/IaC scanners in CI when those tools are provisioned; no committed suppressions should be accepted without owner, expiry, and risk.
