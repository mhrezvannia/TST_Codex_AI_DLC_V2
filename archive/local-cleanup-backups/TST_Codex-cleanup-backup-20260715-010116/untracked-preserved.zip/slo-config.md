# SLO Config - LinerCore Enterprise

## Source Context

This SLO config consumes `performance-design`, `security-design`, `reliability-design`, `monitoring-design`, and `infrastructure-services`. The current repo defines evidence budgets and required signals, but production SLO targets still need environment baselines.

## Initial SLIs

| SLI | Measurement |
|---|---|
| API availability | Successful requests divided by total requests per service. |
| API latency | p95/p99 HTTP request latency per service and route class. |
| Event freshness | Time from domain change to published event visibility. |
| Outbox lag | Oldest unpublished outbox item age per service. |
| Contract health | Green/blocked status of executable contract catalog and provider verification. |
| Readiness health | Required readiness evidence passed/blocked/failed counts. |
| Authorization correctness | Denied-path tests and authorization decision audit results. |

## Initial SLOs

| SLO | Target | Status |
|---|---|---|
| Quality gate evaluation | <= 2 minutes after evidence collection | Defined in performance-design; live measurement pending. |
| Operations dashboard load | p95 <= 2 seconds | Defined in performance-design; live measurement pending. |
| Contract aggregation | <= 60 seconds after checks | Defined in performance-design; offline scripts currently fast. |
| Readiness evidence | 0 failed required checks before promotion | Enforced by local readiness evidence. |
| Contract health | 100% required contract seams green before merge/promotion | Enforced by contract scripts. |

## Error Budget Policy

- If release-candidate readiness has failed required checks, promotion stops.
- If live staging has readiness blockers, production approval is unavailable until blockers are fixed or formally carried with owner/risk.
- If production SLO targets are later breached, feature work pauses for affected service owners until remediation is planned.
