# Smoke Test Results - LinerCore Enterprise

## Source Context

These smoke results consume `cd-config`, `deployment-strategy`, `environment-inventory`, and `build-test-results`. Smoke testing is limited to repository/local runtime evidence because no deployed staging or production environment exists.

## Executed Smoke Tests

| Smoke | Command | Status | Result |
|---|---|---|---|
| Local runtime manifest smoke | `node scripts\smoke-local.mjs` | Passed | Seed pack valid; Compose services, nginx routes, observability profile marker, and core/app/devtools/full profiles present. |
| Observability smoke | `node scripts\smoke-observability.mjs` | Passed | Required observability files and readiness signals present. |
| Local readiness evidence | `node scripts\local-readiness.mjs --profile full --evidence artifacts\readiness\local-readiness.json` | Blocked | 9 passed, 3 blocked, 0 failed; live prerequisites/provider/seed apply need running services. |

## Not Executed

| Smoke | Reason |
|---|---|
| Staging HTTP smoke | No staging endpoint is provisioned. |
| Production post-deploy smoke | No production endpoint is provisioned. |
| Live provider verification | Identity and Reference Data services are not running in this session. |
| Live seed apply | Identity and Reference Data APIs are not running in this session. |

## Result

Offline smoke evidence passed. Live deployment smoke remains blocked until an environment target is provisioned and started.
