# LinerCore System Workflow Map

Last updated: 2026-07-10

This document is the current technical map of the workspace. It summarizes the indexed codebase, the runtime topology, the business workflow, and the gaps that are still visible from the code graph and live stack.

## Source Of Truth

- Graphify index snapshot: `graphify-out/GRAPH_REPORT.md`
- Current workflow checkpoint: `docs/erp-flow-checkpoint.md`
- AI-DLC state: `aidlc/spaces/default/intents/260708-linercore-enterprise/aidlc-state.md`
- Live runtime descriptors: `compose.yaml`, `infrastructure/runtime/profiles.json`, `infrastructure/env/local.env.example`

## Indexed Codebase Snapshot

- Corpus size in the latest graph: 2,077 files and about 952k words.
- Graph size: 27,180 nodes, 28,669 edges, 1,853 communities.
- Graph freshness: built from commit `3ff499df` per the report.

The graph is large enough that it is useful as an architecture map, but it also shows many weakly connected nodes and documentation-heavy communities. That matters because the current system is functionally broad but still uneven in execution quality.

## Runtime Topology

### Canonical Local Runtime

The canonical runnable stack is Docker Compose:

- PostgreSQL
- Keycloak
- Kafka
- Schema Registry
- Identity service
- Reference Data service
- Charge Agreement service
- Booking service
- Container Movement service
- Auth UI
- Reference Data UI
- Charge Agreements UI
- Booking UI
- Container Movement UI
- Nginx gateway

### Host Runtime

There is also a host-run path for local development:

- Spring Boot services can run directly against localhost PostgreSQL.
- Next.js apps can run directly on their own ports.
- UI auth can bypass Keycloak in local dev mode.
- This is a development convenience, not the primary supported runtime shape.

## Module Inventory

### Backend Services

#### Identity Service

- Java Spring container module: `services/identity-service/container`
- Core function: authorization decisions and role assignment
- Persistence: JDBC repositories over PostgreSQL
- Auth model: local Keycloak-style subject resolver, with Docker profile wired to Keycloak issuer/JWKS

#### Reference Data Service

- Java Spring container module: `services/reference-data-service/container`
- Core function: reference record CRUD, validation, change history, and outbox publishing
- Persistence: JDBC repositories over PostgreSQL
- Integration: authorization client, outbox, schema registry, Kafka publisher placeholder

#### Charge Agreement Service

- Java Spring container module: `services/charge-agreement-service/container`
- Core function: charge agreement lifecycle and pricing
- Persistence: JDBC repositories over PostgreSQL

#### Booking Service

- Java Spring container module: `services/booking-service/container`
- Core function: booking draft/create, validate, price, confirm, amend, reconfirm, status intake
- Persistence: JDBC repositories over PostgreSQL
- Integrations:
  - Reference Data validation
  - Charge Agreement pricing
  - Container Movement journey creation and status updates

#### Container Movement Service

- Java Spring container module: `services/container-movement-service/container`
- Core function: journey creation, booking-confirmed intake, movement capture, journey lookup
- Persistence: JDBC repositories over PostgreSQL
- Integrations:
  - Reference Data location validation
  - Booking movement-status callback

### Frontend Apps

#### Auth

- Next app: `apps/auth`
- Purpose: sign-in and session/request-access surfaces

#### Reference Data

- Next app: `apps/reference-data`
- Purpose: reference-set workbench and record CRUD

#### Charge Agreements

- Next app: `apps/charge-agreements`
- Purpose: agreement workbench

#### Booking

- Next app: `apps/booking`
- Purpose: booking workbench

#### Container Movement

- Next app: `apps/container-movement`
- Purpose: journey workbench

### Shared Packages

- `packages/api-core`
- `packages/auth`
- `packages/config`
- `packages/shared-types`
- `packages/transformers`
- `packages/ui`

## Business Workflow

The intended ERP flow is:

1. Seed or create reference data:
   customer, locations, commodity, currency, charge codes, agreement defaults.
2. Create a charge agreement.
3. Approve the charge agreement.
4. Create a booking against the reference data.
5. Validate the booking.
6. Price the booking via Charge Agreement.
7. Confirm the booking.
8. Create or reconcile a container journey from the confirmed booking.
9. Capture departure, arrival, and delivery movement events.
10. Push movement status back into Booking.
11. Restart and verify persistence.

## Data Flow And Integration

### Reference Data

- Reference Data is the system of record for locations and master/reference records.
- Booking and Container Movement depend on it for validation.
- In local mode, the UI can bypass auth, and the backend uses in-process local authorization logic.

### Charge Agreement

- Charge Agreement is the pricing authority.
- Booking calls it for pricing after validation.
- Agreement approval must precede booking pricing if the flow is to remain realistic.

### Booking

- Booking is the orchestration point for commercial execution.
- It owns the booking lifecycle and emits/consumes status information.
- It should become the primary detail page surface for commercial execution, not only a workbench.

### Container Movement

- Container Movement owns journey and movement events.
- It consumes booking confirmation and emits movement-status updates back to Booking.

### Correlation And Idempotency

- Correlation IDs should traverse booking, movement, and pricing calls.
- Idempotency keys matter on booking create/confirm/amend and movement event capture.

## What Is Working

- Backend container modules exist for identity, reference data, charge agreement, booking, and container movement.
- Docker Compose and host runtime descriptors exist.
- Local database schema and seed wiring exist.
- Backend unit and integration tests exist for the core services.
- Booking and Container Movement UIs exist and can be started locally.
- Graphify is current and large enough to serve as an architecture map.

## What Is Not Good Enough Yet

- Several UI actions are present without a strong browser-verified guarantee that every button does what the label says.
- The booking and movement apps are still workbench-first; they need real list/detail/master-detail pages.
- The current experience is too dependent on manual inference from the user.
- The system still needs a stricter end-to-end browser test pass on the real click paths.

## Recommendation

My recommendation is:

1. Freeze feature expansion briefly.
2. Refactor the UI into master-detail modules:
   - list page
   - detail page
   - action panel
   - history/status panel
3. Add browser automation that clicks the exact user flows and verifies state after each click.
4. Tighten the booking and container movement pages first, because those are the most workflow-critical surfaces.
5. Keep Docker Compose as the canonical runtime and host mode as a dev convenience only.
6. Re-run Graphify after the next implementation pass so the document and the graph stay aligned.

If the goal is a production-quality ERP slice, the next pass should optimize for correctness and inspectability, not just coverage of endpoints.
