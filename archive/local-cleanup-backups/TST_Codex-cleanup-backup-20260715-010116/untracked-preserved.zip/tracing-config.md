# Tracing Config - LinerCore Enterprise

## Source Context

This tracing configuration consumes `performance-design`, `security-design`, `reliability-design`, `monitoring-design`, and `infrastructure-services`. Local tracing assets use Jaeger and the OpenTelemetry Collector.

## Trace Propagation

| Concern | Configuration |
|---|---|
| Correlation header | `X-Correlation-Id` at trusted boundaries. |
| Trace context | Add W3C trace context when service runtime instrumentation is introduced. |
| Local collector | `infrastructure/observability/otel-collector.yml`. |
| Trace viewer | Jaeger in the observability/full Compose profile. |
| Evidence linkage | Readiness evidence stores correlation id/run id; event payloads carry correlation/idempotency fields. |

## Required Spans

- Enterprise Web request to service API.
- Booking to Charge pricing/D&D request.
- Booking confirmed event publication.
- CMM booking confirmed consumption and journey reconciliation.
- CMM status publication.
- Booking CMM status consumption and D&D trigger evidence.
- Reference Data mutation to outbox publication.

## Gaps

Service runtime tracing instrumentation is not fully wired. The current state validates tracing configuration assets and correlation-field design, but live trace ingestion requires running services and instrumentation.
