# Unit Test Instructions - LinerCore Enterprise

## Source Context

These instructions consume the construction `code-generation-plan` and `code-summary` artifacts for all units. The active test strategy is Comprehensive, so unit tests must cover domain behavior, application-service orchestration, fakeable ports, UI state rendering, script helpers, and contract validators.

## Test Commands

| Area | Command | Expected coverage |
|---|---|---|
| Java service units | `.\.local-tools\apache-maven\bin\mvn.cmd -f services\pom.xml test` | Identity, Reference Data, Charge, Booking, and CMM domain/application behavior. |
| Script units | `node --test scripts\*.test.mjs` | Seeds, runtime devex, local readiness, observability smoke, contract catalog, provider verification. |
| Reference Data UI/libs | `node .\node_modules\vitest\vitest.mjs --root . run apps\reference-data\app\page.test.tsx apps\reference-data\lib\reference-data.test.ts apps\reference-data\lib\service-clients.test.ts apps\reference-data\lib\contract-catalog.test.ts --config vitest.config.ts` | Workbench rendering, client fallbacks, contract health adapters. |
| Auth package/app | `node .\node_modules\vitest\vitest.mjs --root . run packages\auth\src\index.test.ts apps\auth\lib\auth-server.test.ts --config vitest.config.ts` | Token/session helpers and server-side auth behavior. |
| Charge Agreements UI | `corepack yarn workspace @erp/app-charge-agreements test` | Workbench shell rendering. |

## Coverage Expectations

- Booking must cover lifecycle creation, pricing callback/request outcomes, CMM status consumption, D&D pricing, idempotency, stale-event rejection, denied authorization, and audit/outbox evidence.
- CMM must cover journey creation, expected movement ordering, booking confirmation ingestion, stale replay, movement status outbox mapping, and authorization/reference validation.
- Charge must cover active agreement lookup, pricing quote/D&D outcomes, manual fallback, and lifecycle restrictions.
- Scripts must cover fail-closed evidence behavior and missing/stale/mock-only contract rejection.
