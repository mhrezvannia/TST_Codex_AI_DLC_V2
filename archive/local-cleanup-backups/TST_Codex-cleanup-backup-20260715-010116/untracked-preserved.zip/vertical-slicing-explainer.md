# Why We Slice Vertically (and what horizontal layering cost us)

*A short, shareable explainer for the team starting inception. Tool-agnostic — whether we drive the build with Kiro, Claude, or Codex, this is how we slice work and define "done." Read this before writing a single intent.*

---

## 1. The trap: "all the tests pass, but nothing works"

On the practice project, every layer's tests were green and the system still didn't work. Here's exactly why — because this is the mistake we must not repeat.

When you build **one technical layer at a time** (domain, then persistence, then API, then UI, then the event/integration seam), each layer is tested against **stubs** of its neighbours, never the real ones:

| Layer built in isolation | What its test used instead of the real thing |
|---|---|
| Domain | a fake in-memory repository |
| Persistence | an in-memory database |
| API | a mocked application service |
| Event/messaging | a **placeholder publisher** that returns fake "delivered" and never touches the broker |

Each test passed. But a layer's test only proves *"I behave the way I **assumed** my neighbours behave."* It never proves the **real** layers fit together. That only gets tested when you connect them end-to-end — and with horizontal slicing, **no single unit ever connects them.** It's always "later." So you accumulate green layers that were never wired together.

> **Green meant "each brick is square," not "the wall stands."**

### The concrete failure: the `booking.confirmed` event
- The domain built a confirmed booking. ✅ tested.
- The mapper built an outbox event. ✅ tested.
- The messaging layer built a publisher — but a **placeholder** that never reached Kafka. Its written Definition of Done actually said *"verify the enqueue seam **without requiring live proof**."* ✅ tested.

Every layer green. Yet **no event ever reached the broker**, and Container Movement never learned a booking was confirmed. Each layer was "done"; the job they were collectively meant to do — deliver the event — never worked. Nobody caught it, because *green ≠ working; green only meant "matches my stubs."*

---

## 2. Why vertical slicing fixes it

A **vertical slice** is **one tiny capability taken all the way through every layer at once** — UI → API → domain → database → real event → real consumer.

To *finish* the slice you **have to** connect the real layers. So its "done" is: *"I drove this one path on the running system and watched the real thing happen."* A placeholder can't survive that — you literally cannot mark the slice done, because seeing the event actually arrive **is** the slice. There is no layer-in-isolation left to be falsely green.

### The house analogy
- **Horizontal:** all the plumbing in the whole house, then all the wiring, then all the drywall. Each trade passes its own inspection — but you don't know the **kitchen** works (water + power + cabinets *together*) until the very end, when fixing how they meet is expensive.
- **Vertical:** finish **one room completely** — the kitchen: plumbing + wiring + walls + fixtures connected, water runs, lights turn on — before starting the next. You *know* it works because you used it. And the first room teaches you the pattern for every other room.

> **Horizontal layering lets every part be "done" while the whole is not done. Vertical slicing makes "done" mean a thin whole thread actually works.**

---

## 3. How to slice vertically (for writing intents)

1. **An intent is a thin, user-meaningful journey — cut top-to-bottom, not a layer.**
   - ❌ "Build the booking domain model" (that's a layer)
   - ✅ "A customer-service agent creates, prices, and confirms one booking and sees the container journey open" (a journey through every layer)
2. **Start with a walking skeleton:** the thinnest possible end-to-end path — even trivial data — that proves the pipes connect on the *real* runtime. Then each later slice adds **one real capability** through the whole stack.
3. **Keep each slice thin:** one routing leg, one equipment line, one currency first. Breadth comes later, as *more* slices — not as deeper layers now.
4. **Definition of Done = a behaviour you observed on the running system.** Never "tests pass." Name the exact thing you will watch happen (e.g. "observe the event on the real topic; see the journey row appear").
5. **Cross-layer seams must be real inside the slice** — a real event on a real broker, a real API call — never a stub.

### The checklist for every intent (INVEST-for-us)
- **V**ertical — cuts every layer it needs.
- **E**nd-to-end demonstrable — the DoD is an observed journey.
- **R**eal seams — real events/calls, not stubs.
- **T**hin — the smallest slice that still delivers value.
- **I**ndependent-ish — depends only on *finished* slices.
- **C**ontract-true — field names match the contract exactly (this is how the `equipmentTypeCode` vs `equipmentTypeId` class of bug is prevented).
- **A**uditable done — exits through the audit/verification on a live run.

If a candidate isn't **V**ertical or **E**nd-to-end demonstrable, it's a *task inside* an intent — not an intent.

---

## 4. Two layers of documents in inception — keep them separate

This is the structural decision that makes vertical slicing possible.

| Domain Knowledge Base | Delivery Intents |
|---|---|
| *What the business is* | *What we ship* |
| Organised **by module / bounded context** | Organised **by vertical journey** |
| Durable; the mobs gather + maintain it | One per slice; closed when its journey works |
| Ubiquitous language, entities, rules, module relationships | The thin end-to-end journeys that cut across modules |

Your per-module mobs gathering requirements is exactly right — but that output is **reference knowledge**, not the intent boundary. **Do not make "the module" the unit of delivery.** A module is a unit of *ownership and knowledge*; a journey is the unit of *delivery*. Confusing the two is what produced module-shaped, layer-built, never-integrated software last time.

---

## 5. The rule that would have caught everything

> **No layer, unit, or intent is "done" until the real thing it exists to do has been observed working on the running system.**

"Tests pass" against stubs is not done. A green build tells you the code is internally consistent with its assumptions — not that it does the job. Distrust green until you've watched one real thread work end-to-end.

*(Deeper detail: `RETROSPECTIVE-linercore-aidlc-codex.md` — the full story of what broke and why; `GREENFIELD-GUIDE-aidlc-v2.md` — the A-to-Z method for doing it right from day one. Both are tool-agnostic in principle; where they name a specific engine, that's the mechanism, not the method.)*
