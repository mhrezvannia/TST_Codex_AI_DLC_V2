package com.linercore.platform.booking.domain.model;

/**
 * One equipment assignment line (DCSA). {@code equipmentTypeCode} is a Shared Platform
 * equipment-type reference code (ISO 6346 size/type, e.g. {@code 22GP}); {@code quantity}
 * is the number of units of that type. {@code equipmentId} is the optional physical
 * container number (ISO 6346, e.g. {@code APZU4812090}) — {@code null} at initial
 * confirmation (not yet assigned) and populated on a later re-confirmation once known.
 */
public record EquipmentLine(String equipmentTypeCode, int quantity, String equipmentId) {
    public EquipmentLine {
        if (equipmentTypeCode == null || equipmentTypeCode.isBlank()) {
            throw new IllegalArgumentException("equipment type code is required");
        }
        if (quantity < 1) {
            throw new IllegalArgumentException("equipment quantity must be >= 1");
        }
        equipmentId = (equipmentId == null || equipmentId.isBlank()) ? null : equipmentId.trim();
    }

    /** A line with a type and quantity but no container number yet assigned. */
    public static EquipmentLine ofType(String equipmentTypeCode, int quantity) {
        return new EquipmentLine(equipmentTypeCode, quantity, null);
    }

    public boolean hasContainerNumber() {
        return equipmentId != null;
    }
}
