package com.linercore.platform.booking.domain.model;

/**
 * One ordered leg of a booking's route (DCSA routing). {@code loadUnLocode} and
 * {@code dischargeUnLocode} are UN/LOCODE ports; {@code voyageId} is a Shared Platform
 * Vessel/Voyage reference code the consumer resolves from its own replica.
 *
 * <p>On the full route: the first leg's {@code loadUnLocode} is the POL and the last leg's
 * {@code dischargeUnLocode} is the POD; any intermediate ports are transshipment points.
 */
public record RoutingLeg(int legSequence, UnLocode loadUnLocode, UnLocode dischargeUnLocode, String voyageId) {
    public RoutingLeg {
        if (legSequence < 1) {
            throw new IllegalArgumentException("leg sequence must be >= 1");
        }
        if (loadUnLocode == null || dischargeUnLocode == null) {
            throw new IllegalArgumentException("load and discharge UN/LOCODE are required");
        }
        if (loadUnLocode.equals(dischargeUnLocode)) {
            throw new IllegalArgumentException("load and discharge ports must differ on a leg: " + loadUnLocode.value());
        }
        if (voyageId == null || voyageId.isBlank()) {
            throw new IllegalArgumentException("voyage id is required");
        }
    }
}
