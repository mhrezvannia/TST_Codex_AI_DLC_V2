package com.linercore.platform.booking.domain.model;

import java.util.Locale;

/**
 * UN/LOCODE port/location value object: 5 characters — a 2-letter ISO 3166-1 country
 * code followed by 3 alphanumeric location characters (e.g. {@code NLRTM}, {@code USNYC}).
 * The canonical wire form is the upper-cased 5-character string.
 */
public record UnLocode(String value) {
    public UnLocode {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("UN/LOCODE is required");
        }
        value = value.trim().toUpperCase(Locale.ROOT);
        if (value.length() != 5) {
            throw new IllegalArgumentException("UN/LOCODE must be 5 characters: " + value);
        }
        if (!value.chars().allMatch(c -> (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))) {
            throw new IllegalArgumentException("UN/LOCODE must be alphanumeric: " + value);
        }
        if (!Character.isLetter(value.charAt(0)) || !Character.isLetter(value.charAt(1))) {
            throw new IllegalArgumentException("UN/LOCODE must start with a 2-letter country code: " + value);
        }
    }

    public static UnLocode of(String value) {
        return new UnLocode(value);
    }
}
